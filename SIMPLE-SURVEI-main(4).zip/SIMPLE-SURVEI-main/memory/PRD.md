# AKU Online — Survey Management System (Pemkab Buleleng)

## Problem Statement
Aplikasi web operasional untuk Survei Kepuasan Masyarakat (SKM/IKM) Pemerintah Kabupaten Buleleng. Prioritas: STABLE → RELIABLE → SIMPLE → FAST → SECURE → EASY TO USE. Satu survei aktif pada satu waktu. Publik mengisi tanpa login; Super Admin mengelola via dashboard.

## Architecture
- **Backend**: FastAPI (modular) + MongoDB (motor). Modules: `core.py`, `auth.py`, `scoring.py`, `seed.py`, `survey_routes.py`, `admin_routes.py`, `reports.py`, `server.py`.
- **Frontend**: React 19 + React Router + Tailwind + shadcn/ui + recharts + sonner. Context: Auth, Settings.
- **Auth**: JWT httpOnly cookies (bcrypt, rate limiting, idempotent admin seed). Admin: `admin@gmail.com` / `amin123#`.
- **Theme**: Plus Jakarta Sans, Buleleng Red (#C81E1E) accent on light gray. Logo stored at `/frontend/public/assets/logo.jpg`.

## User Personas
- **Masyarakat** (remaja–lansia, awam digital): mengisi survei publik lewat wizard.
- **Super Admin**: mengelola survei, pertanyaan, responden, analitik, laporan, backup, pengaturan.

## Core Requirements (static)
- Single-survey model; semua config dari database.
- Data diri: Nama (uppercase), NIK (16 digit, unique index, concurrency-safe), WhatsApp (+62 normalize), Email (lowercase), Pekerjaan, Pendidikan.
- Scoring configurable (skala bintang 1–5), IKM/SKM + kategori A/B/C/D.
- Reference code `AS001-ddmmyy` + registration number, timezone WITA.

## Implemented (2026-10-06)
- ✅ Auth: login/logout/me/refresh, bcrypt, brute-force lockout, protected routes.
- ✅ Public survey wizard: Informasi → Data Diri → Penilaian → Saran → Review/Konfirmasi → Success (animated checkmark, copy/print ref). Closed-state page.
- ✅ Submit: validasi FE+BE, normalisasi, scoring, unique NIK (atomic single-doc), reference/registration generation.
- ✅ Dashboard: KPI cards, 6 chart animasi (tren responden, nilai unsur, Tren IKM, donut pekerjaan, distribusi rating, pendidikan), custom tooltip + legend + label, summary otomatis, recent, period filter, skeleton loading.
- ✅ Survey Builder, Question Builder (CRUD, duplicate, reorder, 8 tipe), Respondents (server-side pagination, search, masking, detail, delete).
- ✅ Analytics IKM/SKM (indikator tertinggi/terendah). Reports PDF (reportlab + matplotlib: 5 grafik nyata embedded, tabel header merah kontras, zebra rows, page number) & Excel (openpyxl, 7 sheets, freeze/filter).
- ✅ Backup (JSON) & Restore (preview+confirm), Reset Data (konfigurasi dipertahankan), Settings (logo upload, warna, instansi), Audit Log.
- ✅ Global toasts, confirmation modals, error handling (no stack traces to user), prefers-reduced-motion, responsive + mobile drawer.
- ✅ Seeded: 9 unsur SKM PermenPAN, default pekerjaan/pendidikan options.
- ✅ Tautan "Admin" di footer halaman publik menuju /admin/login.

## Backlog / Remaining
- P1: Drag-and-drop reorder (saat ini tombol naik/turun), unmask toggle di tabel responden, respondent filter lanjutan (pekerjaan/pendidikan/kategori di UI).
- P2: Password reset UI, export per-baris responden, caching dashboard.

## Notes
- Full end-to-end testing belum dijalankan atas permintaan user (finish without testing). Backend flows diverifikasi manual via curl (login, submit, duplicate NIK, validation, dashboard). Frontend public & login diverifikasi via screenshot.

import { useState } from "react";
import api, { apiError } from "@/lib/api";
import { downloadFile } from "@/lib/download";
import { showSuccess, showError } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Database, Download, Upload, Loader2 } from "lucide-react";

export default function BackupRestore() {
  const [backingUp, setBackingUp] = useState(false);
  const [preview, setPreview] = useState(null);
  const [file, setFile] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [restoring, setRestoring] = useState(false);

  const doBackup = async () => {
    setBackingUp(true);
    const ok = await downloadFile("/api/backup", "aku-online-backup.json");
    setBackingUp(false);
    if (ok) showSuccess("✅ Backup berhasil diunduh.");
  };

  const onFile = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    const fd = new FormData();
    fd.append("file", f);
    try {
      const { data } = await api.post("/api/restore/preview", fd);
      setPreview(data);
    } catch (err) { showError("❌ " + apiError(err, "File backup tidak valid.")); setFile(null); setPreview(null); }
  };

  const doRestore = async () => {
    setRestoring(true);
    const fd = new FormData();
    fd.append("file", file);
    try {
      await api.post("/api/restore", fd);
      showSuccess("✅ Data berhasil dipulihkan.");
      setConfirmOpen(false); setPreview(null); setFile(null);
    } catch (err) { showError("❌ " + apiError(err, "Gagal memulihkan data.")); }
    finally { setRestoring(false); }
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">💾 Backup & Restore</h1>
        <p className="text-slate-500 text-sm">Cadangkan dan pulihkan seluruh data aplikasi.</p>
      </div>

      <div className="rounded-xl bg-blue-50 border border-blue-200 p-4 text-sm text-blue-800">
        💾 Lakukan backup secara berkala untuk menghindari kehilangan data.
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-3"><Database className="h-6 w-6 text-primary" /><h3 className="font-semibold text-slate-900">Backup Data</h3></div>
        <p className="text-sm text-slate-500 mb-4">Unduh seluruh konfigurasi survei, pertanyaan, dan data responden dalam satu file JSON.</p>
        <Button onClick={doBackup} disabled={backingUp} data-testid="backup-btn" className="min-h-[46px] bg-primary hover:bg-primary/90">
          {backingUp ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Memproses...</> : <><Download className="h-4 w-4 mr-2" /> Unduh Backup</>}
        </Button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-3"><Upload className="h-6 w-6 text-amber-600" /><h3 className="font-semibold text-slate-900">Restore Data</h3></div>
        <p className="text-sm text-slate-500 mb-4">Unggah file backup JSON untuk memulihkan data. Data saat ini akan digantikan.</p>
        <input type="file" accept="application/json,.json" onChange={onFile} data-testid="restore-file-input"
          className="block w-full text-sm text-slate-600 file:mr-4 file:py-2.5 file:px-4 file:rounded-lg file:border-0 file:bg-slate-100 file:text-slate-700 file:font-medium hover:file:bg-slate-200 file:cursor-pointer" />

        {preview && (
          <div className="mt-4 rounded-lg bg-slate-50 border border-slate-200 p-4 text-sm">
            <p className="font-medium text-slate-800 mb-2">Ringkasan File Backup</p>
            <ul className="space-y-1 text-slate-600">
              <li>📅 Diekspor: {preview.exported_at || "-"}</li>
              <li>❓ Pertanyaan: {preview.questions}</li>
              <li>👥 Responden: {preview.respondents}</li>
              <li>⚙️ Pengaturan: {preview.has_settings ? "Ada" : "Tidak ada"}</li>
            </ul>
            <Button onClick={() => setConfirmOpen(true)} data-testid="restore-btn" className="mt-4 min-h-[44px] bg-amber-600 hover:bg-amber-700 text-white">
              <Upload className="h-4 w-4 mr-2" /> Pulihkan Data Ini
            </Button>
          </div>
        )}
      </div>

      <ConfirmDialog open={confirmOpen} onOpenChange={setConfirmOpen}
        title="⚠️ Pulihkan Data?"
        description="Seluruh data survei, pertanyaan, dan responden saat ini akan digantikan oleh data dari file backup. Tindakan ini tidak dapat dibatalkan."
        confirmText="Ya, Pulihkan" destructive loading={restoring} onConfirm={doRestore} />
    </div>
  );
}

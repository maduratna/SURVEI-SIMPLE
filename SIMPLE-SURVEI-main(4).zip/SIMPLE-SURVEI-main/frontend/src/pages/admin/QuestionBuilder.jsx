import { useState, useEffect } from "react";
import api, { apiError } from "@/lib/api";
import { showSuccess, showError } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import {
  Plus, Pencil, Trash2, Copy, ArrowUp, ArrowDown, GripVertical, Loader2,
} from "lucide-react";

const TYPES = [
  { value: "rating_5", label: "Rating 1–5 (Bintang)" },
  { value: "rating_4", label: "Rating 1–4" },
  { value: "custom_rating", label: "Rating Kustom" },
  { value: "single_choice", label: "Pilihan Tunggal" },
  { value: "multiple_choice", label: "Pilihan Ganda" },
  { value: "yes_no", label: "Ya / Tidak" },
  { value: "text", label: "Teks Singkat" },
  { value: "textarea", label: "Teks Panjang" },
];

const empty = { text: "", type: "rating_5", required: true, indicator: "", weight: 1, options: [], rating_max: 5, rating_labels: {} };

export default function QuestionBuilder() {
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [optionsText, setOptionsText] = useState("");
  const [saving, setSaving] = useState(false);
  const [delId, setDelId] = useState(null);

  const load = async () => {
    setLoading(true);
    try { const { data } = await api.get("/api/questions"); setQuestions(data); }
    catch { showError("❌ Data gagal dimuat."); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const openNew = () => { setEditing(null); setForm(empty); setOptionsText(""); setDialogOpen(true); };
  const openEdit = (q) => {
    setEditing(q);
    setForm({ ...empty, ...q });
    setOptionsText((q.options || []).map((o) => o.label ?? o).join("\n"));
    setDialogOpen(true);
  };

  const save = async () => {
    if (!form.text.trim()) { showError("⚠️ Pertanyaan tidak boleh kosong."); return; }
    setSaving(true);
    const needsOptions = ["single_choice", "multiple_choice"].includes(form.type);
    const options = needsOptions
      ? optionsText.split("\n").map((l) => l.trim()).filter(Boolean).map((label) => ({ label, value: label }))
      : [];
    const body = { ...form, weight: Number(form.weight) || 1, rating_max: Number(form.rating_max) || 5, options };
    try {
      if (editing) await api.put(`/api/questions/${editing.id}`, body);
      else await api.post("/api/questions", body);
      showSuccess("✅ Data berhasil disimpan.");
      setDialogOpen(false);
      load();
    } catch (e) { showError("❌ " + apiError(e, "Data gagal disimpan.")); }
    finally { setSaving(false); }
  };

  const duplicate = async (q) => {
    try { await api.post(`/api/questions/${q.id}/duplicate`); showSuccess("✅ Pertanyaan diduplikat."); load(); }
    catch (e) { showError("❌ " + apiError(e)); }
  };

  const doDelete = async () => {
    try { await api.delete(`/api/questions/${delId}`); showSuccess("✅ Pertanyaan dihapus."); setDelId(null); load(); }
    catch (e) { showError("❌ " + apiError(e)); }
  };

  const move = async (idx, dir) => {
    const arr = [...questions];
    const ni = idx + dir;
    if (ni < 0 || ni >= arr.length) return;
    [arr[idx], arr[ni]] = [arr[ni], arr[idx]];
    setQuestions(arr);
    try { await api.put("/api/questions/reorder", { ids: arr.map((q) => q.id) }); }
    catch { showError("❌ Gagal mengubah urutan."); load(); }
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">❓ Pertanyaan</h1>
          <p className="text-slate-500 text-sm">Kelola pertanyaan, unsur, bobot, dan urutan survei.</p>
        </div>
        <Button onClick={openNew} data-testid="add-question-btn" className="min-h-[46px] bg-primary hover:bg-primary/90">
          <Plus className="h-4 w-4 mr-1" /> Tambah Pertanyaan
        </Button>
      </div>

      {loading ? <div className="space-y-3">{[1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-xl" />)}</div>
        : !questions.length ? (
          <div className="bg-white rounded-xl border border-slate-200 p-10 text-center">
            <div className="text-4xl mb-3">📝</div>
            <p className="font-semibold text-slate-700">BELUM ADA PERTANYAAN</p>
            <p className="text-sm text-slate-400">Silakan tambahkan pertanyaan survei.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {questions.map((q, i) => (
              <div key={q.id} data-testid={`question-row-${i}`} className="bg-white rounded-xl border border-slate-200 p-4 card-hover">
                <div className="flex items-start gap-3">
                  <div className="flex flex-col items-center gap-1 pt-1">
                    <button onClick={() => move(i, -1)} disabled={i === 0} data-testid={`move-up-${i}`} className="text-slate-400 hover:text-primary disabled:opacity-30"><ArrowUp className="h-4 w-4" /></button>
                    <GripVertical className="h-4 w-4 text-slate-300" />
                    <button onClick={() => move(i, 1)} disabled={i === questions.length - 1} data-testid={`move-down-${i}`} className="text-slate-400 hover:text-primary disabled:opacity-30"><ArrowDown className="h-4 w-4" /></button>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-slate-800"><span className="text-primary font-bold mr-1">{i + 1}.</span>{q.text}</p>
                    <div className="flex flex-wrap gap-2 mt-2 text-xs">
                      <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-600">{TYPES.find((t) => t.value === q.type)?.label || q.type}</span>
                      {q.indicator && <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-600">{q.indicator}</span>}
                      <span className="px-2 py-0.5 rounded bg-amber-50 text-amber-600">Bobot: {q.weight}</span>
                      {q.required && <span className="px-2 py-0.5 rounded bg-red-50 text-red-600">Wajib</span>}
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <IconBtn testid={`edit-q-${i}`} onClick={() => openEdit(q)}><Pencil className="h-4 w-4" /></IconBtn>
                    <IconBtn testid={`dup-q-${i}`} onClick={() => duplicate(q)}><Copy className="h-4 w-4" /></IconBtn>
                    <IconBtn testid={`del-q-${i}`} onClick={() => setDelId(q.id)} danger><Trash2 className="h-4 w-4" /></IconBtn>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? "Edit Pertanyaan" : "Tambah Pertanyaan"}</DialogTitle></DialogHeader>
          <div className="space-y-4 py-2">
            <div><Label>Pertanyaan</Label><Textarea data-testid="q-text" value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} className="mt-1.5" /></div>
            <div><Label>Jenis Pertanyaan</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                <SelectTrigger data-testid="q-type" className="mt-1.5 min-h-[44px]"><SelectValue /></SelectTrigger>
                <SelectContent>{TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label>Unsur / Indikator</Label><Input data-testid="q-indicator" value={form.indicator} onChange={(e) => setForm({ ...form, indicator: e.target.value })} className="mt-1.5 min-h-[44px]" /></div>
              <div><Label>Bobot</Label><Input data-testid="q-weight" type="number" step="0.1" value={form.weight} onChange={(e) => setForm({ ...form, weight: e.target.value })} className="mt-1.5 min-h-[44px]" /></div>
            </div>
            {form.type === "custom_rating" && (
              <div><Label>Nilai Maksimum</Label><Input type="number" value={form.rating_max} onChange={(e) => setForm({ ...form, rating_max: e.target.value })} className="mt-1.5 min-h-[44px]" /></div>
            )}
            {["single_choice", "multiple_choice"].includes(form.type) && (
              <div><Label>Pilihan Jawaban (satu per baris)</Label>
                <Textarea data-testid="q-options" value={optionsText} onChange={(e) => setOptionsText(e.target.value)} placeholder={"Pilihan 1\nPilihan 2"} className="mt-1.5" /></div>
            )}
            <div className="flex items-center justify-between">
              <Label>Wajib diisi</Label>
              <Switch checked={form.required} onCheckedChange={(v) => setForm({ ...form, required: v })} data-testid="q-required" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Batal</Button>
            <Button onClick={save} disabled={saving} data-testid="q-save-btn" className="bg-primary hover:bg-primary/90">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Simpan"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}
        title="⚠️ Hapus Data?" description="Data yang dihapus tidak dapat dikembalikan."
        confirmText="🗑️ Ya, Hapus" destructive onConfirm={doDelete} />
    </div>
  );
}

function IconBtn({ children, onClick, testid, danger }) {
  return (
    <button onClick={onClick} data-testid={testid}
      className={`h-9 w-9 rounded-lg flex items-center justify-center transition-colors ${danger ? "text-red-500 hover:bg-red-50" : "text-slate-500 hover:bg-slate-100"}`}>
      {children}
    </button>
  );
}

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { useSettings, resolveAsset } from "@/context/SettingsContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { showSuccess, showError } from "@/lib/notify";
import { Loader2, Lock, Mail, Eye, EyeOff } from "lucide-react";

export default function Login() {
  const { login, user } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) navigate("/admin", { replace: true });
  }, [user, navigate]);

  const submit = async (e) => {
    e.preventDefault();
    if (!email || !password) { showError("⚠️ Mohon isi email dan kata sandi."); return; }
    setLoading(true);
    const res = await login(email.trim(), password);
    setLoading(false);
    if (res.ok) { showSuccess("✅ Berhasil masuk."); navigate("/admin", { replace: true }); }
    else showError("❌ " + res.error);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4 py-10">
      <div className="w-full max-w-md animate-fade-in-up">
        <div className="flex flex-col items-center mb-6">
          <img src={resolveAsset(settings?.logo_url)} alt="Logo" className="h-20 w-20 rounded-xl object-contain bg-white shadow-sm border border-slate-200 p-1" />
          <h1 className="mt-4 text-2xl font-extrabold text-slate-900">{settings?.app_name || "AKU Online"}</h1>
          <p className="text-sm text-slate-500">{settings?.instansi || "Pemerintah Kabupaten Buleleng"}</p>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 sm:p-8">
          <h2 className="text-lg font-semibold text-slate-900 mb-1">Masuk Admin</h2>
          <p className="text-sm text-slate-500 mb-6">Silakan masuk untuk mengelola survei.</p>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <Label htmlFor="email" className="text-slate-700">Email</Label>
              <div className="relative mt-1.5">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input id="email" type="email" data-testid="login-email-input" value={email}
                  onChange={(e) => setEmail(e.target.value)} placeholder="admin@gmail.com"
                  className="pl-9 min-h-[48px]" autoComplete="email" />
              </div>
            </div>
            <div>
              <Label htmlFor="password" className="text-slate-700">Kata Sandi</Label>
              <div className="relative mt-1.5">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input id="password" type={showPw ? "text" : "password"} data-testid="login-password-input"
                  value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"
                  className="pl-9 pr-10 min-h-[48px]" autoComplete="current-password" />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <Button type="submit" data-testid="login-submit-btn" disabled={loading}
              className="w-full min-h-[48px] text-base bg-primary hover:bg-primary/90 active:scale-[0.98] transition-all">
              {loading ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Memproses...</> : "Masuk"}
            </Button>
          </form>
        </div>
        <p className="text-center text-xs text-slate-400 mt-6">
          © {new Date().getFullYear()} {settings?.instansi || "Pemerintah Kabupaten Buleleng"}
        </p>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import api, { apiError } from "@/lib/api";
import { useSettings, resolveAsset } from "@/context/SettingsContext";
import { showSuccess, showError } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, Save, Upload } from "lucide-react";

export default function Settings() {
  const { reload } = useSettings();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await api.get("/api/settings"); setData(data); }
    catch { showError("❌ Data gagal dimuat."); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const set = (k, v) => setData((s) => ({ ...s, [k]: v }));

  const onLogo = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 1.5 * 1024 * 1024) { showError("⚠️ Ukuran logo maksimal 1.5 MB."); return; }
    const reader = new FileReader();
    reader.onload = () => set("logo_url", reader.result);
    reader.readAsDataURL(f);
  };

  const save = async () => {
    setSaving(true);
    try {
      const body = {
        app_name: data.app_name, instansi: data.instansi, logo_url: data.logo_url,
        favicon_url: data.favicon_url || data.logo_url, address: data.address, email: data.email,
        contact: data.contact, website: data.website, primary_color: data.primary_color,
        pdf_footer: data.pdf_footer, timezone: data.timezone,
      };
      await api.put("/api/settings", body);
      await reload();
      showSuccess("✅ Pengaturan berhasil disimpan.");
    } catch (e) { showError("❌ " + apiError(e, "Data gagal disimpan.")); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="max-w-3xl space-y-4"><Skeleton className="h-10 w-48" /><Skeleton className="h-96 rounded-xl" /></div>;

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">⚙️ Pengaturan</h1>
        <p className="text-slate-500 text-sm">Kelola identitas aplikasi dan instansi.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6 flex items-center gap-5">
        <img src={resolveAsset(data.logo_url)} alt="Logo" className="h-20 w-20 rounded-xl object-contain border border-slate-200 p-1" />
        <div>
          <p className="font-medium text-slate-800 mb-2">Logo Aplikasi</p>
          <label className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-sm cursor-pointer transition-colors">
            <Upload className="h-4 w-4" /> Ganti Logo
            <input type="file" accept="image/*" onChange={onLogo} data-testid="logo-upload" className="hidden" />
          </label>
          <p className="text-xs text-slate-400 mt-1.5">Format PNG/JPG, maksimal 1.5 MB.</p>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
        <F label="Nama Aplikasi"><Input data-testid="set-app-name" value={data.app_name || ""} onChange={(e) => set("app_name", e.target.value)} className="min-h-[46px]" /></F>
        <F label="Nama Instansi"><Input data-testid="set-instansi" value={data.instansi || ""} onChange={(e) => set("instansi", e.target.value)} className="min-h-[46px]" /></F>
        <F label="Website"><Input value={data.website || ""} onChange={(e) => set("website", e.target.value)} className="min-h-[46px]" /></F>
        <F label="Email"><Input value={data.email || ""} onChange={(e) => set("email", e.target.value)} className="min-h-[46px]" /></F>
        <F label="Kontak"><Input value={data.contact || ""} onChange={(e) => set("contact", e.target.value)} className="min-h-[46px]" /></F>
        <F label="Timezone"><Input value={data.timezone || ""} onChange={(e) => set("timezone", e.target.value)} className="min-h-[46px]" /></F>
        <F label="Alamat" full><Input value={data.address || ""} onChange={(e) => set("address", e.target.value)} className="min-h-[46px]" /></F>
        <F label="Warna Utama">
          <div className="flex gap-2">
            <input type="color" value={data.primary_color || "#C81E1E"} onChange={(e) => set("primary_color", e.target.value)} data-testid="set-color" className="h-11 w-14 rounded-lg border border-slate-200 cursor-pointer" />
            <Input value={data.primary_color || ""} onChange={(e) => set("primary_color", e.target.value)} className="min-h-[46px]" />
          </div>
        </F>
        <F label="Footer PDF" full><Input value={data.pdf_footer || ""} onChange={(e) => set("pdf_footer", e.target.value)} className="min-h-[46px]" /></F>
      </div>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving} data-testid="settings-save-btn" className="min-h-[46px] px-6 bg-primary hover:bg-primary/90">
          {saving ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Menyimpan...</> : <><Save className="h-4 w-4 mr-2" /> Simpan Pengaturan</>}
        </Button>
      </div>
    </div>
  );
}

function F({ label, children, full }) {
  return <div className={full ? "sm:col-span-2" : ""}><Label className="text-slate-700">{label}</Label><div className="mt-1.5">{children}</div></div>;
}

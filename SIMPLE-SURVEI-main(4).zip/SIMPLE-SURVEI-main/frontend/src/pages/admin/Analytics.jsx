import { useState, useEffect, useCallback } from "react";
import api from "@/lib/api";
import { showError } from "@/lib/notify";
import PeriodFilter from "@/components/admin/PeriodFilter";
import { Skeleton } from "@/components/ui/skeleton";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from "recharts";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function Analytics() {
  const [period, setPeriod] = useState("all");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try { const { data } = await api.get("/api/analytics", { params: { period, start, end } }); setData(data); }
    catch { showError("❌ Data gagal dimuat."); }
    finally { setLoading(false); }
  }, [period, start, end]);

  useEffect(() => { if (period !== "custom" || (start && end)) load(); }, [load, period, start, end]);

  return (
    <div className="max-w-5xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">📈 Analitik IKM/SKM</h1>
          <p className="text-slate-500 text-sm">Analisis nilai kepuasan masyarakat per unsur pelayanan.</p>
        </div>
        <PeriodFilter {...{ period, setPeriod, start, end, setStart, setEnd }} />
      </div>

      {loading ? <Skeleton className="h-40 rounded-xl" /> : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <BigStat label="Nilai IKM/SKM" value={data?.ikm ?? "-"} sub={`${data?.total ?? 0} responden`} color="#C81E1E" />
            <BigStat label="Kategori Mutu" value={data?.category?.label ?? "-"} sub={data?.category?.grade ? `Mutu ${data.category.grade}` : ""} color={data?.category?.color || "#64748B"} />
            <BigStat label="Jumlah Unsur" value={data?.indicators?.length ?? 0} sub="unsur dinilai" color="#2563EB" />
          </div>

          {data?.highest && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5">
                <div className="flex items-center gap-2 text-emerald-700 font-semibold mb-1"><TrendingUp className="h-5 w-5" /> Unsur Tertinggi</div>
                <p className="text-slate-800">{data.highest.indicator}</p>
                <p className="text-2xl font-extrabold text-emerald-700">{data.highest.score}</p>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-xl p-5">
                <div className="flex items-center gap-2 text-red-700 font-semibold mb-1"><TrendingDown className="h-5 w-5" /> Perlu Diperhatikan</div>
                <p className="text-slate-800">{data.lowest?.indicator}</p>
                <p className="text-2xl font-extrabold text-red-700">{data.lowest?.score}</p>
              </div>
            </div>
          )}

          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="font-semibold text-slate-900 mb-4">Nilai Per Unsur Pelayanan</h3>
            {!data?.indicators?.length ? (
              <div className="py-10 text-center"><div className="text-4xl mb-2">📭</div><p className="font-semibold text-slate-700">BELUM ADA DATA</p></div>
            ) : (
              <ResponsiveContainer width="100%" height={Math.max(260, data.indicators.length * 42)}>
                <BarChart data={data.indicators} layout="vertical" margin={{ left: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="indicator" width={160} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="score" radius={[0, 4, 4, 0]} name="Nilai">
                    {data.indicators.map((d, i) => <Cell key={i} fill={d.score >= 76 ? "#059669" : d.score >= 65 ? "#D97706" : "#DC2626"} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          {data?.indicators?.length > 0 && (
            <div className="bg-white rounded-xl border border-slate-200 overflow-hidden scroll-x">
              <table className="w-full text-sm min-w-[480px]">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr><th className="text-left px-4 py-3 font-semibold">Unsur</th><th className="text-right px-4 py-3 font-semibold">Nilai</th><th className="text-right px-4 py-3 font-semibold">Responden</th></tr>
                </thead>
                <tbody>
                  {data.indicators.map((d, i) => (
                    <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-3">{d.indicator}</td>
                      <td className="px-4 py-3 text-right font-bold">{d.score}</td>
                      <td className="px-4 py-3 text-right text-slate-500">{d.count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function BigStat({ label, value, sub, color }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 card-hover">
      <p className="text-sm text-slate-500">{label}</p>
      <p className="text-3xl font-extrabold mt-1" style={{ color }}>{value}</p>
      <p className="text-xs text-slate-400 mt-1">{sub}</p>
    </div>
  );
}

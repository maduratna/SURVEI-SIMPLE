import { useState, useEffect, useCallback } from "react";
import api from "@/lib/api";
import { showError } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronLeft, ChevronRight } from "lucide-react";

const ACTION_LABELS = {
  login: "🔑 Masuk", logout: "🚪 Keluar", edit_survey: "📝 Edit Survei",
  add_question: "➕ Tambah Pertanyaan", edit_question: "✏️ Edit Pertanyaan",
  delete_question: "🗑️ Hapus Pertanyaan", duplicate_question: "📋 Duplikat Pertanyaan",
  reorder_questions: "↕️ Urutkan Pertanyaan", reset_data: "🔄 Reset Data",
  edit_respondent: "✏️ Edit Responden", delete_respondent: "🗑️ Hapus Responden",
  backup: "💾 Backup", restore: "♻️ Restore", settings_change: "⚙️ Ubah Pengaturan",
};

export default function AuditLog() {
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try { const { data } = await api.get("/api/audit", { params: { page, page_size: 20 } }); setData(data); }
    catch { showError("❌ Data gagal dimuat."); }
    finally { setLoading(false); }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  const items = data?.items || [];

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">🧾 Audit Log</h1>
        <p className="text-slate-500 text-sm">Riwayat aktivitas administrator pada sistem.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {loading ? <div className="p-5 space-y-3">{[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-10 rounded" />)}</div>
          : !items.length ? (
            <div className="p-10 text-center"><div className="text-4xl mb-3">📭</div><p className="font-semibold text-slate-700">BELUM ADA DATA</p></div>
          ) : (
            <div className="scroll-x">
              <table className="w-full text-sm min-w-[560px]">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr><th className="text-left px-4 py-3 font-semibold">Waktu</th><th className="text-left px-4 py-3 font-semibold">Admin</th><th className="text-left px-4 py-3 font-semibold">Aksi</th></tr>
                </thead>
                <tbody>
                  {items.map((a) => (
                    <tr key={a.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="px-4 py-3 text-xs whitespace-nowrap text-slate-500">{a.created_at_formatted}</td>
                      <td className="px-4 py-3 text-slate-700">{a.admin_email}</td>
                      <td className="px-4 py-3">{ACTION_LABELS[a.action] || a.action}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
      </div>

      {data && data.pages > 1 && (
        <div className="flex items-center justify-end gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
          <span className="text-sm text-slate-600">Hal {data.page} / {data.pages}</span>
          <Button variant="outline" size="sm" disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
        </div>
      )}
    </div>
  );
}

import { useState, useEffect, useCallback } from "react";
import api from "@/lib/api";
import { showError } from "@/lib/notify";
import PeriodFilter from "@/components/admin/PeriodFilter";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LabelList,
} from "recharts";
import {
  Users, CalendarDays, TrendingUp, Star, Award, MessageSquare,
} from "lucide-react";

const CHART = ["#C81E1E", "#2563EB", "#059669", "#D97706", "#7C3AED", "#64748B", "#0D9488", "#DB2777", "#65A30D"];
const ANIM = 900;

// ---------- custom tooltip ----------
function ChartTooltip({ active, payload, label, unit = "" }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-lg px-3 py-2 text-sm">
      {label !== undefined && <p className="font-semibold text-slate-900 mb-1">{label}</p>}
      {payload.map((p, i) => (
        <p key={i} className="flex items-center gap-2 text-slate-600">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: p.fill || p.stroke || p.color }} />
          {p.name}: <span className="font-bold text-slate-900">{p.value}{unit}</span>
        </p>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const [period, setPeriod] = useState("all");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/api/dashboard", { params: { period, start, end } });
      setData(data);
    } catch { showError("❌ Data gagal dimuat."); }
    finally { setLoading(false); }
  }, [period, start, end]);

  useEffect(() => { if (period !== "custom" || (start && end)) load(); }, [load, period, start, end]);

  const kpi = data?.kpi || {};
  const charts = data?.charts || {};

  const cards = [
    { label: "Total Responden", value: kpi.total ?? 0, icon: Users, color: "text-red-600", bg: "bg-red-50" },
    { label: "Hari Ini", value: kpi.today ?? 0, icon: CalendarDays, color: "text-blue-600", bg: "bg-blue-50" },
    { label: "Bulan Ini", value: kpi.month ?? 0, icon: TrendingUp, color: "text-emerald-600", bg: "bg-emerald-50" },
    { label: "Nilai IKM/SKM", value: kpi.ikm ?? "-", icon: Star, color: "text-amber-600", bg: "bg-amber-50" },
    { label: "Kategori", value: kpi.category?.label ?? "-", icon: Award, color: "text-purple-600", bg: "bg-purple-50", small: true },
    { label: "Saran", value: kpi.suggestions ?? 0, icon: MessageSquare, color: "text-slate-600", bg: "bg-slate-100" },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">📊 Dashboard</h1>
          <p className="text-slate-500 text-sm">Ringkasan kondisi survei berdasarkan data yang tersimpan.</p>
        </div>
        <div className="flex items-center gap-3">
          <StatusBadge status={data?.survey_status} />
          <PeriodFilter {...{ period, setPeriod, start, end, setStart, setEnd }} />
        </div>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {loading
          ? cards.map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
          : cards.map((c, i) => (
            <div key={c.label} data-testid={`kpi-${c.label.toLowerCase().replace(/[^a-z]/g, "-")}`}
              className="bg-white rounded-xl border border-slate-200 p-4 card-hover animate-fade-in-up"
              style={{ animationDelay: `${i * 60}ms` }}>
              <div className={`h-10 w-10 rounded-lg ${c.bg} flex items-center justify-center mb-3`}>
                <c.icon className={`h-5 w-5 ${c.color}`} />
              </div>
              <p className={`font-extrabold text-slate-900 ${c.small ? "text-lg" : "text-2xl sm:text-3xl"}`}>{c.value}</p>
              <p className="text-xs text-slate-500 mt-1">{c.label}</p>
            </div>
          ))}
      </div>

      {/* Summary */}
      {!loading && data?.summary?.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 animate-fade-in-up">
          <h2 className="font-semibold text-slate-900 mb-3">Ringkasan Analisis</h2>
          <ul className="space-y-1.5 text-sm text-slate-700">
            {data.summary.map((s, i) => <li key={i} className="flex gap-2">💡<span>{s}</span></li>)}
          </ul>
        </div>
      )}

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard title="📈 Tren Responden" subtitle="Jumlah responden masuk per tanggal" loading={loading} empty={!charts.trend?.length}>
          <ResponsiveContainer width="100%" height={270}>
            <AreaChart data={charts.trend} margin={{ top: 10, right: 12, left: -14, bottom: 0 }}>
              <defs>
                <linearGradient id="gTrend" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#C81E1E" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#C81E1E" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#64748B" }} tickLine={false} axisLine={{ stroke: "#E2E8F0" }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: "#64748B" }} tickLine={false} axisLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ stroke: "#C81E1E", strokeDasharray: "4 4" }} />
              <Area type="monotone" dataKey="value" stroke="#C81E1E" fill="url(#gTrend)" strokeWidth={2.5}
                dot={{ r: 3, fill: "#C81E1E" }} activeDot={{ r: 5, strokeWidth: 2, stroke: "#fff" }}
                name="Responden" isAnimationActive animationDuration={ANIM} />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="📊 Nilai Per Unsur" subtitle="Nilai kepuasan tiap unsur pelayanan (skala 0–100)" loading={loading} empty={!charts.indicators?.length}>
          <ResponsiveContainer width="100%" height={Math.max(270, (charts.indicators?.length || 1) * 34)}>
            <BarChart data={charts.indicators} layout="vertical" margin={{ top: 4, right: 30, left: 10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10, fill: "#64748B" }} tickLine={false} axisLine={false} />
              <YAxis type="category" dataKey="indicator" width={130} tick={{ fontSize: 9, fill: "#334155" }} tickLine={false} axisLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "#F8FAFC" }} />
              <Bar dataKey="score" radius={[0, 6, 6, 0]} name="Nilai" isAnimationActive animationDuration={ANIM}>
                {(charts.indicators || []).map((d, i) => (
                  <Cell key={i} fill={d.score >= 76.61 ? "#059669" : d.score >= 65 ? "#D97706" : "#DC2626"} />
                ))}
                <LabelList dataKey="score" position="right" style={{ fontSize: 10, fill: "#0F172A", fontWeight: 700 }} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="📈 Tren IKM" subtitle="Perubahan nilai IKM/SKM per tanggal" loading={loading} empty={(charts.ikm_trend?.length || 0) < 2}>
          <ResponsiveContainer width="100%" height={270}>
            <LineChart data={charts.ikm_trend} margin={{ top: 10, right: 12, left: -14, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#64748B" }} tickLine={false} axisLine={{ stroke: "#E2E8F0" }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: "#64748B" }} tickLine={false} axisLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ stroke: "#2563EB", strokeDasharray: "4 4" }} />
              <Line type="monotone" dataKey="value" stroke="#2563EB" strokeWidth={2.5}
                dot={{ r: 3.5, fill: "#2563EB" }} activeDot={{ r: 5.5, strokeWidth: 2, stroke: "#fff" }}
                name="Nilai IKM" isAnimationActive animationDuration={ANIM} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="👥 Distribusi Pekerjaan" subtitle="Komposisi pekerjaan responden" loading={loading} empty={!charts.pekerjaan?.length}>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={charts.pekerjaan} dataKey="value" nameKey="name" cx="50%" cy="50%"
                innerRadius={55} outerRadius={90} paddingAngle={2}
                label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                isAnimationActive animationDuration={ANIM}>
                {(charts.pekerjaan || []).map((_, i) => <Cell key={i} fill={CHART[i % CHART.length]} stroke="#fff" strokeWidth={2} />)}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
              <Legend iconSize={10} iconType="circle" wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="⭐ Distribusi Rating" subtitle="Sebaran jawaban nilai responden" loading={loading} empty={!charts.rating_distribution?.length}>
          <ResponsiveContainer width="100%" height={270}>
            <BarChart data={charts.rating_distribution} margin={{ top: 14, right: 12, left: -14, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#64748B" }} tickLine={false} axisLine={{ stroke: "#E2E8F0" }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: "#64748B" }} tickLine={false} axisLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "#F8FAFC" }} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} name="Jumlah" isAnimationActive animationDuration={ANIM} maxBarSize={48}>
                {(charts.rating_distribution || []).map((d, i) => (
                  <Cell key={i} fill={["#DC2626", "#F97316", "#D97706", "#65A30D", "#059669"][Number(d.name) - 1] || "#D97706"} />
                ))}
                <LabelList dataKey="value" position="top" style={{ fontSize: 11, fill: "#0F172A", fontWeight: 700 }} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="🎓 Distribusi Pendidikan" subtitle="Tingkat pendidikan responden" loading={loading} empty={!charts.pendidikan?.length}>
          <ResponsiveContainer width="100%" height={270}>
            <BarChart data={charts.pendidikan} margin={{ top: 14, right: 12, left: -14, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fill: "#64748B" }} tickLine={false} axisLine={{ stroke: "#E2E8F0" }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 10, fill: "#64748B" }} tickLine={false} axisLine={false} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: "#F8FAFC" }} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]} name="Jumlah" isAnimationActive animationDuration={ANIM} maxBarSize={48}>
                {(charts.pendidikan || []).map((_, i) => <Cell key={i} fill={CHART[i % CHART.length]} />)}
                <LabelList dataKey="value" position="top" style={{ fontSize: 11, fill: "#0F172A", fontWeight: 700 }} />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <RecentCard loading={loading} recent={data?.recent} />
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const open = status === "open";
  return (
    <span data-testid="survey-status-badge" className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold ${open ? "bg-red-100 text-red-700" : "bg-slate-200 text-slate-600"}`}>
      {open ? "🔴 SURVEI TERBUKA" : "⚪ SURVEI DITUTUP"}
    </span>
  );
}

function ChartCard({ title, subtitle, children, loading, empty }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 animate-fade-in-up">
      <h3 className="font-semibold text-slate-900">{title}</h3>
      {subtitle && <p className="text-xs text-slate-400 mb-3">{subtitle}</p>}
      {loading ? <Skeleton className="h-[270px] rounded-lg" />
        : empty ? <EmptyChart /> : children}
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="h-[270px] flex flex-col items-center justify-center text-center">
      <div className="text-3xl mb-2">📭</div>
      <p className="font-semibold text-slate-700">BELUM ADA DATA</p>
      <p className="text-sm text-slate-400">Belum ada responden pada periode yang dipilih.</p>
    </div>
  );
}

function RecentCard({ loading, recent }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 animate-fade-in-up">
      <h3 className="font-semibold text-slate-900 mb-4">🕒 Responden Terbaru</h3>
      {loading ? <Skeleton className="h-[220px] rounded-lg" />
        : !recent?.length ? <EmptyChart />
        : (
          <div className="space-y-2.5">
            {recent.map((r, i) => (
              <div key={i} className="flex items-center justify-between p-2.5 rounded-lg hover:bg-slate-50 transition-colors">
                <div className="min-w-0">
                  <p className="font-medium text-slate-800 text-sm truncate">{r.nama}</p>
                  <p className="text-xs text-slate-400 font-mono">{r.reference_code} · {r.created_at_formatted}</p>
                </div>
                <div className="text-right shrink-0 ml-2">
                  <p className="font-bold text-slate-900 text-sm">{r.score ?? "-"}</p>
                  <span className="text-[10px] px-1.5 py-0.5 rounded font-medium" style={{ background: (r.category?.color || "#64748B") + "22", color: r.category?.color || "#64748B" }}>{r.category?.label || "-"}</span>
                </div>
              </div>
            ))}
          </div>
        )}
    </div>
  );
}

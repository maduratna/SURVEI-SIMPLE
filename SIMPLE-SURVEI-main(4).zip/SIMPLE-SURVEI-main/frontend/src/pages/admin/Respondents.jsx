import { useState, useEffect, useCallback } from "react";
import api, { apiError } from "@/lib/api";
import { showSuccess, showError } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Search, Eye, Trash2, Printer, ChevronLeft, ChevronRight } from "lucide-react";

export default function Respondents() {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail] = useState(null);
  const [delId, setDelId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get("/api/respondents", { params: { search, page, page_size: 10 } });
      setData(data);
    } catch { showError("❌ Data gagal dimuat."); }
    finally { setLoading(false); }
  }, [search, page]);

  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [load]);

  const openDetail = async (id) => {
    try { const { data } = await api.get(`/api/respondents/${id}`); setDetail(data); }
    catch (e) { showError("❌ " + apiError(e)); }
  };

  const doDelete = async () => {
    try { await api.delete(`/api/respondents/${delId}`); showSuccess("✅ Responden dihapus."); setDelId(null); load(); }
    catch (e) { showError("❌ " + apiError(e)); }
  };

  const items = data?.items || [];

  return (
    <div className="max-w-7xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">👥 Responden</h1>
        <p className="text-slate-500 text-sm">Kelola dan tinjau data responden survei.</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
        <Input data-testid="respondent-search" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          placeholder="Cari nama, NIK, reference, email..." className="pl-9 min-h-[46px] bg-white" />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        {loading ? <div className="p-5 space-y-3">{[1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-12 rounded" />)}</div>
          : !items.length ? (
            <div className="p-10 text-center"><div className="text-4xl mb-3">📭</div>
              <p className="font-semibold text-slate-700">BELUM ADA DATA</p>
              <p className="text-sm text-slate-400">Belum ada responden pada periode yang dipilih.</p></div>
          ) : (
            <div className="scroll-x">
              <table className="w-full text-sm min-w-[920px]">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <tr>{["No", "Reference", "Tanggal", "Nama", "NIK", "WhatsApp", "Email", "Pekerjaan", "Score", "Kategori", "Aksi"].map((h) => (
                    <th key={h} className="text-left font-semibold px-3 py-3 whitespace-nowrap">{h}</th>))}</tr>
                </thead>
                <tbody>
                  {items.map((r, i) => (
                    <tr key={r.id} data-testid={`respondent-row-${i}`} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-3">{(data.page - 1) * data.page_size + i + 1}</td>
                      <td className="px-3 py-3 font-mono text-xs">{r.reference_code}</td>
                      <td className="px-3 py-3 whitespace-nowrap text-xs">{r.created_at_formatted}</td>
                      <td className="px-3 py-3 font-medium whitespace-nowrap">{r.nama}</td>
                      <td className="px-3 py-3 font-mono text-xs">{r.nik}</td>
                      <td className="px-3 py-3 font-mono text-xs">{r.whatsapp}</td>
                      <td className="px-3 py-3 text-xs">{r.email}</td>
                      <td className="px-3 py-3">{r.pekerjaan}</td>
                      <td className="px-3 py-3 font-bold">{r.score ?? "-"}</td>
                      <td className="px-3 py-3"><span className="text-xs px-2 py-0.5 rounded font-medium whitespace-nowrap" style={{ background: (r.category?.color || "#64748B") + "22", color: r.category?.color || "#64748B" }}>{r.category?.label || "-"}</span></td>
                      <td className="px-3 py-3">
                        <div className="flex gap-1">
                          <button onClick={() => openDetail(r.id)} data-testid={`view-resp-${i}`} className="h-8 w-8 rounded flex items-center justify-center text-slate-500 hover:bg-slate-100"><Eye className="h-4 w-4" /></button>
                          <button onClick={() => setDelId(r.id)} data-testid={`del-resp-${i}`} className="h-8 w-8 rounded flex items-center justify-center text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
      </div>

      {data && data.pages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-slate-500">Total {data.total} responden</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)} data-testid="page-prev"><ChevronLeft className="h-4 w-4" /></Button>
            <span className="text-sm text-slate-600">Hal {data.page} / {data.pages}</span>
            <Button variant="outline" size="sm" disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} data-testid="page-next"><ChevronRight className="h-4 w-4" /></Button>
          </div>
        </div>
      )}

      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" data-testid="respondent-detail">
          <DialogHeader><DialogTitle>Detail Responden</DialogTitle></DialogHeader>
          {detail && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                <D l="Reference" v={detail.reference_code} />
                <D l="Registrasi" v={detail.registration_number} />
                <D l="Nama" v={detail.nama} />
                <D l="NIK" v={detail.nik} />
                <D l="WhatsApp" v={detail.whatsapp} />
                <D l="Email" v={detail.email} />
                <D l="Pekerjaan" v={detail.pekerjaan} />
                <D l="Pendidikan" v={detail.pendidikan} />
                <D l="Score" v={detail.score} />
                <D l="Kategori" v={detail.category?.label} />
                <D l="Waktu" v={detail.created_at_formatted} />
              </div>
              <div>
                <p className="font-semibold text-slate-900 mb-2">Jawaban</p>
                <div className="space-y-1.5">
                  {detail.answers_detail?.map((a, i) => (
                    <div key={i} className="flex justify-between gap-2 border-b border-slate-100 pb-1.5">
                      <span className="text-slate-600 flex-1">{a.question}</span>
                      <span className="font-semibold text-slate-900">{Array.isArray(a.value) ? a.value.join(", ") : a.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              {detail.suggestion && <div><p className="font-semibold text-slate-900 mb-1">Saran</p><p className="text-slate-600 italic">"{detail.suggestion}"</p></div>}
              <Button onClick={() => window.print()} variant="outline" className="w-full" data-testid="print-resp-btn"><Printer className="h-4 w-4 mr-2" /> Cetak</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!delId} onOpenChange={(o) => !o && setDelId(null)}
        title="⚠️ Hapus Data?" description="Data responden yang dihapus tidak dapat dikembalikan."
        confirmText="🗑️ Ya, Hapus" destructive onConfirm={doDelete} />
    </div>
  );
}

function D({ l, v }) {
  return <div><p className="text-xs text-slate-400">{l}</p><p className="font-medium text-slate-800 break-all">{v ?? "-"}</p></div>;
}

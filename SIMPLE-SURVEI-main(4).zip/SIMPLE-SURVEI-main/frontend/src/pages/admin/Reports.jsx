import { useState } from "react";
import PeriodFilter from "@/components/admin/PeriodFilter";
import { downloadFile } from "@/lib/download";
import { showSuccess } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { FileText, FileSpreadsheet, Loader2 } from "lucide-react";

export default function Reports() {
  const [period, setPeriod] = useState("all");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [loadingPdf, setLoadingPdf] = useState(false);
  const [loadingXls, setLoadingXls] = useState(false);

  const gen = async (type) => {
    const setL = type === "pdf" ? setLoadingPdf : setLoadingXls;
    setL(true);
    const ok = await downloadFile(`/api/reports/${type}`, `laporan.${type === "pdf" ? "pdf" : "xlsx"}`, { period, start, end });
    setL(false);
    if (ok) showSuccess(`✅ Laporan ${type.toUpperCase()} berhasil dibuat.`);
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">📄 Laporan</h1>
        <p className="text-slate-500 text-sm">Buat laporan PDF atau Excel sesuai periode yang dipilih.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5">
        <p className="font-medium text-slate-700 mb-3">Pilih Periode Laporan</p>
        <PeriodFilter {...{ period, setPeriod, start, end, setStart, setEnd }} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-6 card-hover text-center">
          <div className="mx-auto h-14 w-14 rounded-xl bg-red-50 flex items-center justify-center mb-4"><FileText className="h-7 w-7 text-red-600" /></div>
          <h3 className="font-semibold text-slate-900">Laporan PDF</h3>
          <p className="text-sm text-slate-500 mb-4">Laporan siap cetak dengan kop surat instansi.</p>
          <Button onClick={() => gen("pdf")} disabled={loadingPdf} data-testid="gen-pdf-btn" className="w-full min-h-[46px] bg-primary hover:bg-primary/90">
            {loadingPdf ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Menghasilkan PDF...</> : "Buat PDF"}
          </Button>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-6 card-hover text-center">
          <div className="mx-auto h-14 w-14 rounded-xl bg-emerald-50 flex items-center justify-center mb-4"><FileSpreadsheet className="h-7 w-7 text-emerald-600" /></div>
          <h3 className="font-semibold text-slate-900">Laporan Excel</h3>
          <p className="text-sm text-slate-500 mb-4">Data lengkap dalam beberapa lembar kerja.</p>
          <Button onClick={() => gen("excel")} disabled={loadingXls} data-testid="gen-excel-btn" className="w-full min-h-[46px] bg-emerald-600 hover:bg-emerald-700 text-white">
            {loadingXls ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Menghasilkan Excel...</> : "Buat Excel"}
          </Button>
        </div>
      </div>
    </div>
  );
}

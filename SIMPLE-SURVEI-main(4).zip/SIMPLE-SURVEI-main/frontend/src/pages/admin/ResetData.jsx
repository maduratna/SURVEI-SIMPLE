import { useState } from "react";
import api, { apiError } from "@/lib/api";
import { showSuccess, showError } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { RotateCcw } from "lucide-react";

export default function ResetData() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const doReset = async () => {
    setLoading(true);
    try {
      await api.post("/api/reset", { confirm: true });
      showSuccess("✅ DATA SURVEI BERHASIL DIRESET. Survei siap digunakan kembali.");
      setOpen(false);
    } catch (e) { showError("❌ " + apiError(e, "Gagal mereset data.")); }
    finally { setLoading(false); }
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">🔄 Reset Data Survei</h1>
        <p className="text-slate-500 text-sm">Hapus seluruh data responden tanpa menghapus konfigurasi survei.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <div className="rounded-xl bg-red-50 border border-red-200 p-4 mb-5">
          <p className="font-semibold text-red-700">⚠️ RESET DATA SURVEI?</p>
          <p className="text-sm text-red-600 mt-1">Seluruh data responden, jawaban, skor dan hasil analitik akan dihapus. Konfigurasi survei tetap dipertahankan.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm mb-5">
          <div className="rounded-lg bg-red-50/50 border border-red-100 p-4">
            <p className="font-medium text-red-700 mb-2">Akan Dihapus</p>
            <ul className="text-slate-600 space-y-1">
              <li>• Data responden</li><li>• Jawaban & skor</li><li>• Statistik & analitik</li><li>• Saran & masukan</li>
            </ul>
          </div>
          <div className="rounded-lg bg-emerald-50/50 border border-emerald-100 p-4">
            <p className="font-medium text-emerald-700 mb-2">Tetap Dipertahankan</p>
            <ul className="text-slate-600 space-y-1">
              <li>• Judul & deskripsi</li><li>• Pertanyaan & pilihan</li><li>• Indikator & bobot</li><li>• Konfigurasi survei</li>
            </ul>
          </div>
        </div>

        <Button onClick={() => setOpen(true)} data-testid="open-reset-btn" className="min-h-[46px] bg-red-600 hover:bg-red-700 text-white">
          <RotateCcw className="h-4 w-4 mr-2" /> Reset Data Survei
        </Button>
      </div>

      <ConfirmDialog open={open} onOpenChange={setOpen}
        title="⚠️ RESET DATA SURVEI?"
        description="Seluruh data responden, jawaban, skor dan hasil analitik akan dihapus. Konfigurasi survei tetap dipertahankan."
        confirmText="🔄 Ya, Reset Data" destructive loading={loading} onConfirm={doReset} />
    </div>
  );
}

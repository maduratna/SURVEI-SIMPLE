import { useState, useEffect } from "react";
import api, { apiError } from "@/lib/api";
import { showSuccess, showError } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2, Save } from "lucide-react";

export default function SurveyBuilder() {
  const [survey, setSurvey] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try { const { data } = await api.get("/api/survey"); setSurvey(data); }
    catch { showError("❌ Data gagal dimuat."); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const set = (k, v) => setSurvey((s) => ({ ...s, [k]: v }));

  const save = async () => {
    setSaving(true);
    try {
      const body = {
        title: survey.title, description: survey.description, service_name: survey.service_name,
        period_start: survey.period_start, period_end: survey.period_end, status: survey.status,
        intro_info: survey.intro_info, instructions: survey.instructions, closing_info: survey.closing_info,
      };
      const { data } = await api.put("/api/survey", body);
      setSurvey(data);
      showSuccess("✅ Data berhasil disimpan.");
    } catch (e) { showError("❌ " + apiError(e, "Data gagal disimpan.")); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="max-w-3xl space-y-4"><Skeleton className="h-10 w-64" /><Skeleton className="h-96 rounded-xl" /></div>;

  const open = survey.status === "open";

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900">📝 Survei</h1>
        <p className="text-slate-500 text-sm">Kelola informasi dan status survei yang sedang berjalan.</p>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 flex items-center justify-between">
        <div>
          <p className="font-semibold text-slate-900">Status Survei</p>
          <p className="text-sm text-slate-500">{open ? "🔴 Survei terbuka untuk pengisian publik." : "⚪ Survei ditutup dari pengisian publik."}</p>
        </div>
        <Switch checked={open} onCheckedChange={(v) => set("status", v ? "open" : "closed")} data-testid="survey-status-switch" />
      </div>

      <div className="bg-white rounded-xl border border-slate-200 p-5 sm:p-6 space-y-4">
        <Field label="Judul Survei"><Input data-testid="survey-title" value={survey.title || ""} onChange={(e) => set("title", e.target.value)} className="min-h-[46px]" /></Field>
        <Field label="Nama Layanan"><Input data-testid="survey-service" value={survey.service_name || ""} onChange={(e) => set("service_name", e.target.value)} className="min-h-[46px]" /></Field>
        <Field label="Deskripsi"><Textarea data-testid="survey-description" value={survey.description || ""} onChange={(e) => set("description", e.target.value)} className="min-h-[90px]" /></Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Periode Mulai"><Input type="date" data-testid="survey-period-start" value={survey.period_start || ""} onChange={(e) => set("period_start", e.target.value)} className="min-h-[46px]" /></Field>
          <Field label="Periode Selesai"><Input type="date" data-testid="survey-period-end" value={survey.period_end || ""} onChange={(e) => set("period_end", e.target.value)} className="min-h-[46px]" /></Field>
        </div>
        <Field label="Informasi Pembuka"><Textarea value={survey.intro_info || ""} onChange={(e) => set("intro_info", e.target.value)} className="min-h-[70px]" /></Field>
        <Field label="Instruksi Pengisian"><Textarea value={survey.instructions || ""} onChange={(e) => set("instructions", e.target.value)} className="min-h-[70px]" /></Field>
        <Field label="Informasi Penutup"><Textarea value={survey.closing_info || ""} onChange={(e) => set("closing_info", e.target.value)} className="min-h-[70px]" /></Field>
      </div>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving} data-testid="survey-save-btn" className="min-h-[46px] px-6 bg-primary hover:bg-primary/90">
          {saving ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Menyimpan...</> : <><Save className="h-4 w-4 mr-2" /> Simpan Perubahan</>}
        </Button>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return <div><Label className="text-slate-700">{label}</Label><div className="mt-1.5">{children}</div></div>;
}

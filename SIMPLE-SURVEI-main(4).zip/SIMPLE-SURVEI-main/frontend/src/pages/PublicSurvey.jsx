import { useState, useEffect, useMemo } from "react";
import { Link } from "react-router-dom";
import api, { apiError } from "@/lib/api";
import { resolveAsset } from "@/context/SettingsContext";
import QuestionField from "@/components/QuestionField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { showError, showSuccess, showWarning } from "@/lib/notify";
import {
  Loader2, CheckCircle2, ArrowRight, ArrowLeft, Copy, Printer, Home,
  ClipboardList, User, Star, MessageSquare, FileCheck, Info,
} from "lucide-react";

const STEPS = [
  { key: "info", label: "Informasi", icon: Info },
  { key: "diri", label: "Data Diri", icon: User },
  { key: "nilai", label: "Penilaian", icon: Star },
  { key: "saran", label: "Saran", icon: MessageSquare },
  { key: "review", label: "Selesai", icon: FileCheck },
];

export default function PublicSurvey() {
  const [state, setState] = useState("loading"); // loading | open | closed | error
  const [data, setData] = useState(null);
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({ nama: "", nik: "", whatsapp: "", email: "", pekerjaan: "", pendidikan: "" });
  const [answers, setAnswers] = useState({});
  const [suggestion, setSuggestion] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);

  const load = async () => {
    setState("loading");
    try {
      const { data } = await api.get("/api/public/survey");
      if (data.status === "closed") { setData(data); setState("closed"); }
      else { setData(data); setState("open"); }
    } catch {
      setState("error");
    }
  };
  useEffect(() => { load(); }, []);

  const fields = data?.survey?.respondent_fields || {};
  const questions = data?.questions || [];
  const app = data?.app || {};

  const setF = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const formatNik = (value) => (value || "").replace(/\D/g, "").slice(0, 16).match(/.{1,4}/g)?.join("-") || "";

  const validateDiri = () => {
    const f = fields;
    if (f.nama?.required && !form.nama.trim()) return "⚠️ Nama wajib diisi.";
    if (f.nik?.required && !form.nik) return "⚠️ NIK wajib diisi.";
    if (form.nik && !/^\d{16}$/.test(form.nik)) return "❌ NIK tidak valid. NIK harus terdiri dari 16 digit.";
    if (f.whatsapp?.required && !form.whatsapp) return "⚠️ Nomor WhatsApp wajib diisi.";
    if (form.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) return "❌ Format email tidak valid.";
    if (f.email?.required && !form.email) return "⚠️ Email wajib diisi.";
    if (f.pekerjaan?.required && !form.pekerjaan) return "⚠️ Pekerjaan wajib dipilih.";
    if (f.pendidikan?.required && !form.pendidikan) return "⚠️ Pendidikan wajib dipilih.";
    return null;
  };

  const validateNilai = () => {
    for (const q of questions) {
      if (q.required) {
        const v = answers[q.id];
        if (v === undefined || v === "" || (Array.isArray(v) && v.length === 0))
          return "⚠️ Mohon lengkapi semua pertanyaan yang wajib diisi.";
      }
    }
    return null;
  };

  const next = () => {
    if (step === 1) { const e = validateDiri(); if (e) { showError(e); return; } }
    if (step === 2) { const e = validateNilai(); if (e) { showError(e); return; } }
    setStep((s) => Math.min(s + 1, STEPS.length - 1));
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const back = () => { setStep((s) => Math.max(s - 1, 0)); window.scrollTo({ top: 0, behavior: "smooth" }); };

  const doSubmit = async () => {
    setSubmitting(true);
    try {
      const payload = {
        ...form,
        answers: Object.entries(answers).map(([question_id, value]) => ({ question_id, value })),
        suggestion,
      };
      const { data: res } = await api.post("/api/public/submit", payload);
      setResult(res);
      setConfirmOpen(false);
      showSuccess("🎉 Survei berhasil dikirim.");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (e) {
      setConfirmOpen(false);
      showError("❌ " + apiError(e, "Data gagal disimpan."));
    } finally {
      setSubmitting(false);
    }
  };

  // ---------- RENDER STATES ----------
  if (state === "loading")
    return <CenterWrap><Loader2 className="h-10 w-10 animate-spin text-primary" /><p className="mt-4 text-slate-500">⏳ Memuat survei...</p></CenterWrap>;

  if (state === "error")
    return <CenterWrap>
      <p className="text-slate-700 text-lg">❌ Data gagal dimuat.</p>
      <Button onClick={load} className="mt-4" data-testid="retry-btn">Coba Lagi</Button>
    </CenterWrap>;

  if (state === "closed")
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <PublicHeader app={app} />
        <div className="flex-1 flex items-center justify-center px-4 py-10">
          <div className="max-w-md text-center bg-white rounded-xl border border-slate-200 shadow-sm p-8 animate-fade-in-up" data-testid="survey-closed">
            <div className="text-5xl mb-4">📋</div>
            <h1 className="text-xl font-bold text-slate-900">SURVEI SEDANG DITUTUP</h1>
            <p className="mt-3 text-slate-600">Saat ini survei belum dibuka untuk pengisian. Silakan kembali lagi nanti.</p>
          </div>
        </div>
        <PublicFooter app={app} />
      </div>
    );

  if (result)
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col">
        <PublicHeader app={app} />
        <div className="flex-1 flex items-center justify-center px-4 py-10">
          <SuccessCard result={result} app={app} data={data} />
        </div>
        <PublicFooter app={app} />
      </div>
    );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <PublicHeader app={app} />
      <main className="flex-1 w-full max-w-3xl mx-auto px-4 py-6 sm:py-8">
        <Stepper step={step} />
        <div className="mt-6 bg-white rounded-xl border border-slate-200 shadow-sm p-5 sm:p-7 animate-fade-in-up" key={step}>
          {step === 0 && <InfoStep data={data} />}
          {step === 1 && <DiriStep form={form} setF={setF} fields={fields} data={data} />}
          {step === 2 && <NilaiStep questions={questions} answers={answers} setAnswers={setAnswers} />}
          {step === 3 && <SaranStep suggestion={suggestion} setSuggestion={setSuggestion} />}
          {step === 4 && <ReviewStep form={form} answers={answers} questions={questions} suggestion={suggestion} />}
        </div>

        <div className="mt-6 flex items-center justify-between gap-3">
          {step > 0 ? (
            <Button variant="outline" onClick={back} data-testid="back-btn" className="min-h-[48px] px-5">
              <ArrowLeft className="h-4 w-4 mr-1" /> Kembali
            </Button>
          ) : <span />}
          {step < STEPS.length - 1 ? (
            <Button onClick={next} data-testid="next-btn" className="min-h-[48px] px-6 bg-primary hover:bg-primary/90 active:scale-[0.98] transition-all">
              {step === 0 ? "Mulai Isi Survei" : "Lanjut"} <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          ) : (
            <Button onClick={() => setConfirmOpen(true)} data-testid="open-submit-btn"
              className="min-h-[48px] px-6 bg-primary hover:bg-primary/90 active:scale-[0.98] transition-all">
              <FileCheck className="h-4 w-4 mr-1" /> Kirim Survei
            </Button>
          )}
        </div>
      </main>
      <PublicFooter app={app} />

      <ConfirmDialog
        open={confirmOpen}
        onOpenChange={setConfirmOpen}
        title="📋 Periksa Kembali"
        description="Pastikan data dan jawaban Anda sudah benar sebelum dikirim."
        confirmText="✓ Kirim Survei"
        cancelText="Batal"
        onConfirm={doSubmit}
        loading={submitting}
      />
    </div>
  );
}

// ---------- sub components ----------
function CenterWrap({ children }) {
  return <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4 text-center">{children}</div>;
}

function PublicHeader({ app }) {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center gap-3">
        <img src={resolveAsset(app?.logo_url)} alt="Logo" className="h-11 w-11 rounded-lg object-contain border border-slate-200 p-0.5" />
        <div className="leading-tight">
          <p className="font-extrabold text-slate-900">{app?.app_name || "AKU Online"}</p>
          <p className="text-xs text-slate-500">{app?.instansi || "Pemerintah Kabupaten Buleleng"}</p>
        </div>
      </div>
    </header>
  );
}

function PublicFooter({ app }) {
  return (
    <footer className="bg-white border-t border-slate-200 py-4 text-center">
      <p className="text-xs text-slate-400">
        © {new Date().getFullYear()} {app?.instansi || "Pemerintah Kabupaten Buleleng"}
        {app?.website && <> · <a href={app.website} target="_blank" rel="noreferrer" className="text-primary hover:underline">{app.website.replace(/^https?:\/\//, "")}</a></>}
        {" · "}
        <Link to="/admin/login" data-testid="admin-login-link" className="text-slate-400 hover:text-primary hover:underline">Admin</Link>
      </p>
    </footer>
  );
}

function Stepper({ step }) {
  // show 4 main stages: Data Diri, Penilaian, Saran, Selesai  (info is intro)
  const stages = STEPS.slice(1);
  const activeIdx = Math.max(0, step - 1);
  return (
    <div className="flex items-center justify-between gap-1" data-testid="wizard-stepper">
      {stages.map((s, i) => {
        const done = i < activeIdx;
        const active = i === activeIdx && step > 0;
        return (
          <div key={s.key} className="flex-1 flex flex-col items-center">
            <div className={`flex items-center w-full`}>
              <div className={`h-1 flex-1 rounded ${i === 0 ? "opacity-0" : done || active ? "bg-primary" : "bg-slate-200"}`} />
              <div className={`h-9 w-9 shrink-0 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                done ? "bg-primary text-white" : active ? "bg-primary text-white ring-4 ring-red-100" : "bg-slate-200 text-slate-500"
              }`}>
                {done ? "✓" : i + 1}
              </div>
              <div className={`h-1 flex-1 rounded ${i === stages.length - 1 ? "opacity-0" : done ? "bg-primary" : "bg-slate-200"}`} />
            </div>
            <span className={`mt-1.5 text-[11px] sm:text-xs font-medium ${active || done ? "text-primary" : "text-slate-400"}`}>{s.label}</span>
          </div>
        );
      })}
    </div>
  );
}

function InfoStep({ data }) {
  const s = data.survey;
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-primary"><ClipboardList className="h-5 w-5" /><span className="text-xs font-semibold uppercase tracking-wide">Informasi Survei</span></div>
      <h1 className="text-2xl font-extrabold text-slate-900">{s.title}</h1>
      {s.description && <p className="text-slate-600 leading-relaxed">{s.description}</p>}
      {s.intro_info && <div className="rounded-xl bg-accent/60 border border-red-100 p-4 text-slate-700">{s.intro_info}</div>}
      {s.instructions && <div className="rounded-xl bg-slate-50 border border-slate-200 p-4 text-sm text-slate-600"><b>Petunjuk:</b> {s.instructions}</div>}
      <p className="text-sm text-slate-500">💡 Seluruh data Anda dijamin kerahasiaannya dan hanya digunakan untuk peningkatan pelayanan.</p>
    </div>
  );
}

function FieldHint({ children }) {
  return <p className="text-xs text-slate-500 mt-1">{children}</p>;
}

function DiriStep({ form, setF, fields, data }) {
  return (
    <div className="space-y-5">
      <p className="text-sm text-slate-500">💡 Silakan isi data sesuai identitas Anda.</p>
      {fields.nama?.visible !== false && (
        <div>
          <Label className="text-slate-700">Nama Lengkap {fields.nama?.required && <span className="text-primary">*</span>}</Label>
          <Input data-testid="field-nama" value={form.nama} className="mt-1.5 min-h-[48px] uppercase"
            onChange={(e) => setF("nama", e.target.value.toUpperCase())} placeholder="NAMA LENGKAP" />
        </div>
      )}
      {fields.nik?.visible !== false && (
        <div>
          <Label className="text-slate-700">NIK {fields.nik?.required && <span className="text-primary">*</span>}</Label>
          <Input data-testid="field-nik" value={formatNik(form.nik)} inputMode="numeric" maxLength={19}
            className="mt-1.5 min-h-[48px] font-mono tracking-wide"
            onChange={(e) => setF("nik", e.target.value.replace(/\D/g, "").slice(0, 16))} placeholder="XXXX-XXXX-XXXX-XXXX" />
          <div className="flex justify-between"><FieldHint>ℹ️ Masukkan 16 digit NIK. Tanda hubung ditambahkan otomatis setiap 4 digit.</FieldHint>
            <span className={`text-xs mt-1 font-mono ${form.nik.length === 16 ? "text-emerald-600" : "text-slate-400"}`}>{form.nik.length}/16</span></div>
        </div>
      )}
      {fields.whatsapp?.visible !== false && (
        <div>
          <Label className="text-slate-700">WhatsApp {fields.whatsapp?.required && <span className="text-primary">*</span>}</Label>
          <div className="mt-1.5 flex">
            <span className="inline-flex items-center px-3 rounded-l-lg border border-r-0 border-input bg-slate-100 text-slate-600 font-medium">+62</span>
            <Input data-testid="field-whatsapp" value={form.whatsapp} inputMode="numeric"
              className="rounded-l-none min-h-[48px]"
              onChange={(e) => setF("whatsapp", e.target.value.replace(/\D/g, ""))} placeholder="81234567890" />
          </div>
          <FieldHint>📱 Masukkan nomor WhatsApp aktif. Anda tidak perlu mengetik +62.</FieldHint>
        </div>
      )}
      {fields.email?.visible !== false && (
        <div>
          <Label className="text-slate-700">Email {fields.email?.required && <span className="text-primary">*</span>}</Label>
          <Input data-testid="field-email" type="email" value={form.email} className="mt-1.5 min-h-[48px]"
            onChange={(e) => setF("email", e.target.value)} placeholder="nama@email.com" />
        </div>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {fields.pekerjaan?.visible !== false && (
          <div>
            <Label className="text-slate-700">Pekerjaan {fields.pekerjaan?.required && <span className="text-primary">*</span>}</Label>
            <Select value={form.pekerjaan} onValueChange={(v) => setF("pekerjaan", v)}>
              <SelectTrigger data-testid="field-pekerjaan" className="mt-1.5 min-h-[48px]"><SelectValue placeholder="Pilih pekerjaan" /></SelectTrigger>
              <SelectContent>{(data.survey.pekerjaan_options || []).map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        )}
        {fields.pendidikan?.visible !== false && (
          <div>
            <Label className="text-slate-700">Pendidikan {fields.pendidikan?.required && <span className="text-primary">*</span>}</Label>
            <Select value={form.pendidikan} onValueChange={(v) => setF("pendidikan", v)}>
              <SelectTrigger data-testid="field-pendidikan" className="mt-1.5 min-h-[48px]"><SelectValue placeholder="Pilih pendidikan" /></SelectTrigger>
              <SelectContent>{(data.survey.pendidikan_options || []).map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        )}
      </div>
    </div>
  );
}

function NilaiStep({ questions, answers, setAnswers }) {
  const set = (id, v) => setAnswers((a) => ({ ...a, [id]: v }));
  if (!questions.length)
    return <div className="text-center py-10"><div className="text-4xl mb-3">📝</div><p className="font-semibold text-slate-700">BELUM ADA PERTANYAAN</p></div>;
  return (
    <div className="space-y-6">
      <p className="text-sm text-slate-500">⭐ Berikan penilaian sesuai pengalaman Anda.</p>
      {questions.map((q, i) => (
        <div key={q.id} className="pb-5 border-b border-slate-100 last:border-0">
          <p className="font-medium text-slate-800 mb-3">
            <span className="text-primary font-bold mr-1">{i + 1}.</span>{q.text}
            {q.required && <span className="text-primary ml-1">*</span>}
          </p>
          {q.indicator && <p className="text-xs text-slate-400 mb-2">Unsur: {q.indicator}</p>}
          <QuestionField question={q} value={answers[q.id]} onChange={(v) => set(q.id, v)} />
        </div>
      ))}
    </div>
  );
}

function SaranStep({ suggestion, setSuggestion }) {
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-primary"><MessageSquare className="h-5 w-5" /><span className="text-xs font-semibold uppercase tracking-wide">Saran & Masukan</span></div>
      <p className="text-sm text-slate-500">💬 Sampaikan saran atau masukan Anda (opsional).</p>
      <Textarea data-testid="field-suggestion" value={suggestion} onChange={(e) => setSuggestion(e.target.value)}
        placeholder="Tulis saran atau masukan Anda di sini..." className="min-h-[140px]" />
    </div>
  );
}

function ReviewStep({ form, answers, questions, suggestion }) {
  return (
    <div className="space-y-5">
      <div className="rounded-xl bg-amber-50 border border-amber-200 p-4 text-sm text-amber-800">
        ⚠️ Periksa kembali data dan jawaban sebelum mengirim.
      </div>
      <div>
        <h3 className="font-semibold text-slate-900 mb-2">Data Diri</h3>
        <dl className="text-sm divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
          {[["Nama", form.nama], ["NIK", formatNik(form.nik)], ["WhatsApp", form.whatsapp ? "+62" + form.whatsapp : "-"],
            ["Email", form.email || "-"], ["Pekerjaan", form.pekerjaan || "-"], ["Pendidikan", form.pendidikan || "-"]].map(([k, v]) => (
            <div key={k} className="flex px-4 py-2.5 bg-white"><dt className="w-32 text-slate-500">{k}</dt><dd className="flex-1 font-medium text-slate-800 break-all">{v || "-"}</dd></div>
          ))}
        </dl>
      </div>
      <div>
        <h3 className="font-semibold text-slate-900 mb-2">Penilaian</h3>
        <ul className="text-sm space-y-1.5">
          {questions.map((q, i) => (
            <li key={q.id} className="flex gap-2">
              <span className="text-slate-500">{i + 1}.</span>
              <span className="flex-1 text-slate-700">{q.text}</span>
              <span className="font-semibold text-slate-900">{Array.isArray(answers[q.id]) ? answers[q.id].join(", ") : (answers[q.id] ?? "-")}</span>
            </li>
          ))}
        </ul>
      </div>
      {suggestion && <div><h3 className="font-semibold text-slate-900 mb-1">Saran</h3><p className="text-sm text-slate-600 italic">"{suggestion}"</p></div>}
    </div>
  );
}

function SuccessCard({ result, app, data }) {
  const copy = () => { navigator.clipboard.writeText(result.reference_code); showSuccess("✅ Kode referensi disalin."); };
  return (
    <div className="max-w-md w-full text-center bg-white rounded-xl border border-slate-200 shadow-sm p-8 animate-scale-in" data-testid="success-card">
      <div className="mx-auto h-20 w-20 rounded-full bg-emerald-100 flex items-center justify-center animate-check-pop">
        <CheckCircle2 className="h-12 w-12 text-emerald-600" />
      </div>
      <h1 className="mt-5 text-xl font-extrabold text-slate-900">🎉 SURVEI BERHASIL DIKIRIM</h1>
      <p className="mt-2 text-slate-600">{data?.survey?.closing_info || "Terima kasih telah berpartisipasi."}</p>

      <div className="mt-6 rounded-xl bg-slate-50 border border-slate-200 p-4 text-left space-y-2">
        <Row label="Kode Referensi" value={result.reference_code} mono testid="result-reference" />
        <Row label="Nomor Registrasi" value={result.registration_number} mono />
        <Row label="Waktu" value={result.submitted_at_formatted} />
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3">
        <Button onClick={copy} variant="outline" data-testid="copy-ref-btn" className="min-h-[48px]"><Copy className="h-4 w-4 mr-1" /> Salin Kode</Button>
        <Button onClick={() => window.print()} variant="outline" data-testid="print-btn" className="min-h-[48px]"><Printer className="h-4 w-4 mr-1" /> Cetak Bukti</Button>
      </div>
      <Button asChild className="mt-3 w-full min-h-[48px] bg-primary hover:bg-primary/90" data-testid="back-home-btn">
        <a href="/"><Home className="h-4 w-4 mr-1" /> Kembali ke Beranda</a>
      </Button>
    </div>
  );
}

function Row({ label, value, mono, testid }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-sm text-slate-500">{label}</span>
      <span data-testid={testid} className={`text-sm font-semibold text-slate-900 ${mono ? "font-mono" : ""}`}>{value}</span>
    </div>
  );
}

import { createContext, useContext, useState, useEffect } from "react";
import api from "@/lib/api";

const SettingsContext = createContext(null);
const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

export function resolveAsset(url) {
  if (!url) return "/assets/logo.jpg";
  if (url.startsWith("http") || url.startsWith("data:")) return url;
  return url; // served from frontend public
}

export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState(null);

  const load = async () => {
    try {
      const { data } = await api.get("/api/public/settings");
      setSettings(data);
      if (data?.primary_color) {
        document.documentElement.style.setProperty("--brand", data.primary_color);
      }
      if (data?.favicon_url) {
        let link = document.querySelector("link[rel='icon']");
        if (link) link.href = resolveAsset(data.favicon_url);
      }
      if (data?.app_name) document.title = `${data.app_name} | Survei Kepuasan Masyarakat`;
    } catch { /* keep defaults */ }
  };

  useEffect(() => { load(); }, []);

  return (
    <SettingsContext.Provider value={{ settings, reload: load, backendUrl: BACKEND_URL }}>
      {children}
    </SettingsContext.Provider>
  );
}

export const useSettings = () => useContext(SettingsContext);

import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export function ConfirmDialog({
  open, onOpenChange, title, description, confirmText = "Ya, Lanjutkan",
  cancelText = "Batal", onConfirm, destructive = false, loading = false,
}) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="rounded-xl" data-testid="confirm-dialog">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-lg">{title}</AlertDialogTitle>
          <AlertDialogDescription className="text-base text-slate-600">
            {description}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={loading} data-testid="confirm-cancel-btn" className="min-h-[44px]">
            {cancelText}
          </AlertDialogCancel>
          <AlertDialogAction
            data-testid="confirm-ok-btn"
            disabled={loading}
            onClick={(e) => { e.preventDefault(); onConfirm?.(); }}
            className={`min-h-[44px] ${destructive ? "bg-red-600 hover:bg-red-700" : "bg-primary hover:bg-primary/90"} text-white`}
          >
            {loading ? "Memproses..." : confirmText}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

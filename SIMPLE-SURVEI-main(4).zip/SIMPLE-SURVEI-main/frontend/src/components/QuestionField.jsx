import { Star } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function QuestionField({ question, value, onChange }) {
  const t = question.type;

  if (t === "rating_5" || t === "rating_4" || t === "custom_rating") {
    const max = t === "rating_4" ? 4 : t === "rating_5" ? 5 : (question.rating_max || 5);
    const labels = question.rating_labels || {};
    return (
      <div>
        <div className="flex flex-wrap gap-1.5" data-testid={`rating-${question.id}`}>
          {Array.from({ length: max }, (_, i) => i + 1).map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => onChange(n)}
              data-testid={`rating-${question.id}-${n}`}
              className="group p-1 transition-transform hover:scale-110 active:scale-95"
              aria-label={`Nilai ${n}`}
            >
              <Star
                className={`h-9 w-9 sm:h-10 sm:w-10 transition-colors ${
                  value >= n ? "fill-amber-400 text-amber-400" : "text-slate-300 group-hover:text-amber-300"
                }`}
              />
            </button>
          ))}
        </div>
        {value ? (
          <p className="mt-1.5 text-sm font-medium text-slate-600">
            {value} - {labels[String(value)] || ""}
          </p>
        ) : (
          <p className="mt-1.5 text-sm text-slate-400">Ketuk bintang untuk memberi nilai</p>
        )}
      </div>
    );
  }

  if (t === "yes_no") {
    return (
      <div className="flex gap-3" data-testid={`yesno-${question.id}`}>
        {[["Ya", "Ya"], ["Tidak", "Tidak"]].map(([label, val]) => (
          <button
            key={val}
            type="button"
            onClick={() => onChange(val)}
            className={`flex-1 min-h-[48px] rounded-xl border text-base font-medium transition-all ${
              value === val
                ? "border-primary bg-accent text-primary"
                : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
            }`}
          >
            {label}
          </button>
        ))}
      </div>
    );
  }

  if (t === "single_choice") {
    return (
      <div className="space-y-2" data-testid={`single-${question.id}`}>
        {(question.options || []).map((opt, i) => {
          const label = opt.label ?? opt;
          return (
            <button
              key={i}
              type="button"
              onClick={() => onChange(label)}
              className={`w-full text-left min-h-[48px] px-4 rounded-xl border transition-all ${
                value === label
                  ? "border-primary bg-accent text-primary font-medium"
                  : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>
    );
  }

  if (t === "multiple_choice") {
    const arr = Array.isArray(value) ? value : [];
    const toggle = (label) =>
      onChange(arr.includes(label) ? arr.filter((x) => x !== label) : [...arr, label]);
    return (
      <div className="space-y-2" data-testid={`multi-${question.id}`}>
        {(question.options || []).map((opt, i) => {
          const label = opt.label ?? opt;
          const active = arr.includes(label);
          return (
            <button
              key={i}
              type="button"
              onClick={() => toggle(label)}
              className={`w-full text-left min-h-[48px] px-4 rounded-xl border transition-all flex items-center gap-3 ${
                active ? "border-primary bg-accent text-primary font-medium" : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
              }`}
            >
              <span className={`h-5 w-5 rounded border flex items-center justify-center ${active ? "bg-primary border-primary text-white" : "border-slate-300"}`}>
                {active && "✓"}
              </span>
              {label}
            </button>
          );
        })}
      </div>
    );
  }

  if (t === "textarea") {
    return (
      <Textarea
        data-testid={`text-${question.id}`}
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Tulis jawaban Anda..."
        className="min-h-[96px]"
      />
    );
  }

  return (
    <Input
      data-testid={`text-${question.id}`}
      value={value || ""}
      onChange={(e) => onChange(e.target.value)}
      placeholder="Tulis jawaban Anda..."
      className="min-h-[48px]"
    />
  );
}

import { useState } from "react";
import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { useSettings, resolveAsset } from "@/context/SettingsContext";
import { Button } from "@/components/ui/button";
import { ConfirmDialog } from "@/components/ConfirmDialog";
import { showSuccess } from "@/lib/notify";
import {
  LayoutDashboard, FileText, HelpCircle, Users, BarChart3, FileDown,
  Database, Settings as SettingsIcon, RotateCcw, ScrollText, LogOut, Menu, X,
} from "lucide-react";

const NAV = [
  { to: "/admin", end: true, label: "Dashboard", icon: LayoutDashboard, emoji: "📊" },
  { to: "/admin/survei", label: "Survei", icon: FileText, emoji: "📝" },
  { to: "/admin/pertanyaan", label: "Pertanyaan", icon: HelpCircle, emoji: "❓" },
  { to: "/admin/responden", label: "Responden", icon: Users, emoji: "👥" },
  { to: "/admin/analitik", label: "Analitik", icon: BarChart3, emoji: "📈" },
  { to: "/admin/laporan", label: "Laporan", icon: FileDown, emoji: "📄" },
  { to: "/admin/backup", label: "Backup & Restore", icon: Database, emoji: "💾" },
  { to: "/admin/pengaturan", label: "Pengaturan", icon: SettingsIcon, emoji: "⚙️" },
  { to: "/admin/reset", label: "Reset Data", icon: RotateCcw, emoji: "🔄" },
  { to: "/admin/audit", label: "Audit Log", icon: ScrollText, emoji: "🧾" },
];

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const { settings } = useSettings();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);

  const doLogout = async () => {
    await logout();
    showSuccess("✅ Anda telah keluar.");
    navigate("/admin/login", { replace: true });
  };

  const SidebarContent = () => (
    <>
      <div className="flex items-center gap-3 px-5 py-5 border-b border-slate-200">
        <img src={resolveAsset(settings?.logo_url)} alt="Logo" className="h-10 w-10 rounded-lg object-contain border border-slate-200 p-0.5" />
        <div className="leading-tight">
          <p className="font-extrabold text-slate-900 text-sm">{settings?.app_name || "AKU Online"}</p>
          <p className="text-[11px] text-slate-500">{settings?.instansi || "Pemkab Buleleng"}</p>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {NAV.map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.end}
            onClick={() => setOpen(false)}
            data-testid={`nav-${n.label.toLowerCase().replace(/[^a-z]/g, "-")}`}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                isActive ? "bg-accent text-primary" : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              }`
            }
          >
            <n.icon className="h-[18px] w-[18px]" />
            {n.label}
          </NavLink>
        ))}
      </nav>
      <div className="px-3 py-4 border-t border-slate-200">
        <div className="px-3 py-2 mb-2">
          <p className="text-xs text-slate-400">Masuk sebagai</p>
          <p className="text-sm font-medium text-slate-700 truncate">{user?.email}</p>
        </div>
        <Button variant="outline" onClick={() => setConfirmLogout(true)} data-testid="logout-btn"
          className="w-full justify-start text-slate-600 hover:text-primary min-h-[44px]">
          <LogOut className="h-4 w-4 mr-2" /> Keluar
        </Button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-64 flex-col bg-white border-r border-slate-200 fixed inset-y-0 z-30">
        <SidebarContent />
      </aside>

      {/* Mobile drawer */}
      {open && (
        <>
          <div className="fixed inset-0 bg-black/40 z-40 lg:hidden" onClick={() => setOpen(false)} />
          <aside className="fixed inset-y-0 left-0 w-72 bg-white z-50 flex flex-col lg:hidden animate-fade-in-up">
            <SidebarContent />
          </aside>
        </>
      )}

      <div className="flex-1 lg:ml-64 flex flex-col min-w-0">
        {/* Topbar */}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-20 lg:hidden">
          <div className="px-4 py-3 flex items-center justify-between">
            <button onClick={() => setOpen(true)} data-testid="mobile-menu-btn" className="p-2 -ml-2 text-slate-600">
              <Menu className="h-6 w-6" />
            </button>
            <div className="flex items-center gap-2">
              <img src={resolveAsset(settings?.logo_url)} alt="Logo" className="h-8 w-8 rounded object-contain" />
              <span className="font-bold text-slate-900">{settings?.app_name || "AKU Online"}</span>
            </div>
            <span className="w-8" />
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">
          <Outlet />
        </main>
      </div>

      <ConfirmDialog
        open={confirmLogout}
        onOpenChange={setConfirmLogout}
        title="Keluar dari aplikasi?"
        description="Anda perlu masuk kembali untuk mengakses dashboard admin."
        confirmText="Ya, Keluar"
        onConfirm={doLogout}
      />
    </div>
  );
}

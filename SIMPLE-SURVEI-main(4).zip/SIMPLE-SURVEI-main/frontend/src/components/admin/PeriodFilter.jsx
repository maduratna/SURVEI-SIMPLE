import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { PERIODS } from "@/lib/download";

export default function PeriodFilter({ period, setPeriod, start, end, setStart, setEnd }) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select value={period} onValueChange={setPeriod}>
        <SelectTrigger data-testid="period-select" className="w-[150px] min-h-[42px] bg-white">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {PERIODS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
        </SelectContent>
      </Select>
      {period === "custom" && (
        <>
          <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} data-testid="period-start" className="w-[150px] min-h-[42px] bg-white" />
          <span className="text-slate-400">s/d</span>
          <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} data-testid="period-end" className="w-[150px] min-h-[42px] bg-white" />
        </>
      )}
    </div>
  );
}

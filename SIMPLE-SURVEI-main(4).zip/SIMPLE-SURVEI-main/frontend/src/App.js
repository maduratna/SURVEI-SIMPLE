import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { SettingsProvider } from "@/context/SettingsContext";

import PublicSurvey from "@/pages/PublicSurvey";
import Login from "@/pages/admin/Login";
import AdminLayout from "@/components/admin/AdminLayout";
import Dashboard from "@/pages/admin/Dashboard";
import SurveyBuilder from "@/pages/admin/SurveyBuilder";
import QuestionBuilder from "@/pages/admin/QuestionBuilder";
import Respondents from "@/pages/admin/Respondents";
import Analytics from "@/pages/admin/Analytics";
import Reports from "@/pages/admin/Reports";
import BackupRestore from "@/pages/admin/BackupRestore";
import Settings from "@/pages/admin/Settings";
import ResetData from "@/pages/admin/ResetData";
import AuditLog from "@/pages/admin/AuditLog";

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="h-10 w-10 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!user) return <Navigate to="/admin/login" replace />;
  return children;
}

function App() {
  return (
    <div className="App">
      <SettingsProvider>
        <AuthProvider>
          <BrowserRouter>
            <Toaster position="top-right" richColors closeButton />
            <Routes>
              <Route path="/" element={<PublicSurvey />} />
              <Route path="/admin/login" element={<Login />} />
              <Route path="/admin" element={<ProtectedRoute><AdminLayout /></ProtectedRoute>}>
                <Route index element={<Dashboard />} />
                <Route path="survei" element={<SurveyBuilder />} />
                <Route path="pertanyaan" element={<QuestionBuilder />} />
                <Route path="responden" element={<Respondents />} />
                <Route path="analitik" element={<Analytics />} />
                <Route path="laporan" element={<Reports />} />
                <Route path="backup" element={<BackupRestore />} />
                <Route path="pengaturan" element={<Settings />} />
                <Route path="reset" element={<ResetData />} />
                <Route path="audit" element={<AuditLog />} />
              </Route>
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </SettingsProvider>
    </div>
  );
}

export default App;

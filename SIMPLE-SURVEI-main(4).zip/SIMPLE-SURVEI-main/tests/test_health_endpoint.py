"""Health endpoint unit tests. This does not claim a real MySQL server is available."""
import asyncio
import importlib
import os
import sys
import types

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
if "mysql_store" not in sys.modules:
    import tests.test_mysql_store_unit  # noqa: F401

# Auth imports bcrypt at module import time; no hashing is performed by these health tests.
if "bcrypt" not in sys.modules:
    bcrypt = types.ModuleType("bcrypt")
    bcrypt.hashpw = lambda value, salt: b"test-hash"
    bcrypt.gensalt = lambda: b"test-salt"
    bcrypt.checkpw = lambda value, hashed: False
    sys.modules["bcrypt"] = bcrypt

server = importlib.import_module("server")


class FakeCursor:
    async def __aenter__(self): return self
    async def __aexit__(self, *args): return False
    async def execute(self, sql): self.sql = sql
    async def fetchone(self): return (1,)


class FakeConnection:
    async def __aenter__(self): return self
    async def __aexit__(self, *args): return False
    def cursor(self, *args): return FakeCursor()


class FakePool:
    def acquire(self): return FakeConnection()


class HealthyDB:
    pool = FakePool()
    async def initialize(self): return None


class UnhealthyDB:
    pool = None
    async def initialize(self): raise ConnectionError("database not reachable")


def test_health_endpoint_reports_database_ready():
    async def scenario():
        old_db = server.db
        try:
            server.db = HealthyDB()
            result = await server.health()
            assert result == {"status": "ok", "database": "ok"}
        finally:
            server.db = old_db
    asyncio.run(scenario())


def test_health_endpoint_returns_503_when_database_is_unavailable():
    async def scenario():
        old_db = server.db
        try:
            server.db = UnhealthyDB()
            result = await server.health()
            assert result.status_code == 503
            assert result.body == b'{"status":"degraded","database":"unavailable"}'
        finally:
            server.db = old_db
    asyncio.run(scenario())

"""Endpoint-level public submission tests using an isolated in-memory persistence double."""
import asyncio
import importlib
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

# test_mysql_store_unit installs dependency stubs when the external packages are unavailable.
if "mysql_store" not in sys.modules:
    import tests.test_mysql_store_unit  # noqa: F401

ms = importlib.import_module("mysql_store")
core = importlib.import_module("core")
survey_routes = importlib.import_module("survey_routes")


class MemoryDB:
    def __init__(self):
        self.survey = MemoryCollection("survey")
        self.settings = MemoryCollection("settings")
        self.questions = MemoryCollection("questions")
        self.respondents = MemoryCollection("respondents")
        self.counters = MemoryCollection("counters")
        self.audit_logs = MemoryCollection("audit_logs")

    async def seed(self):
        await self._seed()

    async def _seed(self):
        await self.survey.insert_one({
            "_id": "main", "status": "open", "title": "Test survey",
            "categories": core.DEFAULT_CATEGORIES if hasattr(core, "DEFAULT_CATEGORIES") else None,
            "closing_info": "Terima kasih",
            "respondent_fields": {
                "nama": {"required": True}, "nik": {"required": True},
                "whatsapp": {"required": False}, "email": {"required": False},
                "pekerjaan": {"required": True}, "pendidikan": {"required": True},
            },
        })
        await self.questions.insert_one({
            "_id": "question-1", "text": "Penilaian", "type": "rating_5",
            "required": True, "indicator": "Pelayanan", "order": 0,
        })
        await self.respondents.create_index("nik", unique=True, partialFilterExpression={"nik": {"$gt": ""}})
        await self.respondents.create_index("reference_code", unique=True)


class MemoryCollection(ms.Collection):
    def __init__(self, name):
        super().__init__(object(), name)
        self.documents = {}

    async def _all(self):
        import copy
        return [copy.deepcopy(item) for item in self.documents.values()]

    async def _save(self, document, insert=False):
        import copy
        normalized = self._normalize(document)
        if insert and str(normalized["_id"]) in self.documents:
            raise RuntimeError("duplicate _id")
        self.documents[str(normalized["_id"])] = copy.deepcopy(normalized)
        document.clear()
        document.update(normalized)

    async def _delete_id(self, document_id):
        self.documents.pop(str(document_id), None)


def run(coro):
    return asyncio.run(coro)


def body(nik="3201-1508-1234-5678"):
    return survey_routes.SubmitBody(
        nama="  budi   santoso ", nik=nik, whatsapp="08123456789", email="USER@EXAMPLE.COM",
        pekerjaan="Guru", pendidikan="S1", answers=[{"question_id": "question-1", "value": 5}],
        suggestion="Sangat baik",
    )


def test_public_submit_normalizes_nik_and_returns_reference():
    async def scenario():
        database = MemoryDB()
        await database.seed()
        survey_routes.db = database
        survey_routes.next_sequence = lambda name: async_value(7)
        result = await survey_routes.public_submit(body())
        assert result["reference_code"].startswith("AS007-")
        stored = await database.respondents.find_one({"reference_code": result["reference_code"]})
        assert stored["nik"] == "3201150812345678"
        assert stored["nama"] == "BUDI SANTOSO"
        assert stored["email"] == "user@example.com"
    run(scenario())


def test_public_submit_rejects_invalid_nik():
    async def scenario():
        database = MemoryDB()
        await database.seed()
        survey_routes.db = database
        try:
            await survey_routes.public_submit(body("1234-5678"))
        except survey_routes.HTTPException as exc:
            assert exc.status_code == 422
            assert "16 digit" in exc.detail
        else:
            raise AssertionError("NIK bukan 16 digit harus ditolak")
        assert await database.respondents.count_documents({}) == 0
    run(scenario())


def test_public_submit_rejects_duplicate_nik():
    async def scenario():
        database = MemoryDB()
        await database.seed()
        survey_routes.db = database
        survey_routes.next_sequence = lambda name: async_value(8)
        await survey_routes.public_submit(body())
        try:
            await survey_routes.public_submit(body("3201150812345678"))
        except survey_routes.HTTPException as exc:
            assert exc.status_code == 409
            assert "NIK" in exc.detail
        else:
            raise AssertionError("NIK ganda harus ditolak")
        assert await database.respondents.count_documents({}) == 1
    run(scenario())


def test_public_submit_rejects_closed_survey():
    async def scenario():
        database = MemoryDB()
        await database.seed()
        survey_routes.db = database
        await database.survey.update_one({"_id": "main"}, {"$set": {"status": "closed"}})
        try:
            await survey_routes.public_submit(body())
        except survey_routes.HTTPException as exc:
            assert exc.status_code == 403
        else:
            raise AssertionError("Survei tertutup harus menolak submission")
    run(scenario())


async def async_value(value):
    return value


def test_public_submit_rejects_missing_required_answer():
    async def scenario():
        database = MemoryDB()
        await database.seed()
        survey_routes.db = database
        try:
            await survey_routes.public_submit(survey_routes.SubmitBody(
                nama="Budi", nik="3201150812345678", pekerjaan="Guru", pendidikan="S1", answers=[]
            ))
        except survey_routes.HTTPException as exc:
            assert exc.status_code == 422
            assert "pertanyaan yang wajib" in exc.detail
        else:
            raise AssertionError("Jawaban pertanyaan wajib harus ditolak")
        assert await database.respondents.count_documents({}) == 0
    run(scenario())


def test_public_submit_rejects_invalid_email():
    async def scenario():
        database = MemoryDB()
        await database.seed()
        survey_routes.db = database
        try:
            await survey_routes.public_submit(body())
        except survey_routes.HTTPException as exc:
            # Email is optional, but if supplied it must have a valid format.
            raise AssertionError(f"Email example in body should be valid: {exc.detail}")
        invalid = body()
        invalid.email = "not-an-email"
        try:
            await survey_routes.public_submit(invalid)
        except survey_routes.HTTPException as exc:
            assert exc.status_code == 422
            assert "email" in exc.detail.lower()
        else:
            raise AssertionError("Email tidak valid harus ditolak")
    run(scenario())

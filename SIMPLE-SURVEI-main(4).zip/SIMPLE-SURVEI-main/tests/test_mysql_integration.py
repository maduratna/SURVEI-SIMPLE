"""Optional integration tests against a real disposable MySQL database.

Set MYSQL_TEST_URL to a TEST-ONLY database URL and run:
    pytest -q tests/test_mysql_integration.py
Never point this at a production database: the test writes and deletes test rows.
"""
import os
import pytest

MYSQL_TEST_URL = os.getenv("MYSQL_TEST_URL")
pytestmark = pytest.mark.skipif(not MYSQL_TEST_URL, reason="MYSQL_TEST_URL belum diatur (perlu MySQL test server)")


def test_real_mysql_constraints_and_atomic_counter():
    import asyncio
    import importlib
    import sys
    import uuid
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
    # The env is captured when mysql_store is imported.
    os.environ["MYSQL_URL"] = MYSQL_TEST_URL
    sys.modules.pop("mysql_store", None)
    mysql_store = importlib.import_module("mysql_store")
    db = mysql_store.Database()
    suffix = uuid.uuid4().hex[:12]
    responder_id_1 = f"it-resp-1-{suffix}"
    responder_id_2 = f"it-resp-2-{suffix}"
    responder_id_3 = f"it-resp-3-{suffix}"
    user_id_1 = f"it-user-1-{suffix}"
    user_id_2 = f"it-user-2-{suffix}"
    # 16-digit NIKs unique for this run and safe for storage.
    nik = "9" + (uuid.uuid4().int % 10**15).__str__().zfill(15)
    nik2 = "8" + (uuid.uuid4().int % 10**15).__str__().zfill(15)
    reference = f"IT-{suffix}"

    async def scenario():
        try:
            await db.initialize()
            # Atomic counter: every concurrent caller must receive a distinct contiguous value.
            values = await asyncio.gather(*(db.increment_counter(f"pytest-{suffix}") for _ in range(20)))
            assert len(set(values)) == 20
            assert sorted(values) == list(range(min(values), max(values) + 1))

            # Canonical NIK + native unique index must reject duplicates without overwriting row 1.
            await db.respondents.insert_one({"_id": responder_id_1, "nik": f"{nik[:4]}-{nik[4:8]}-{nik[8:12]}-{nik[12:]}", "reference_code": reference})
            first = await db.respondents.find_one({"_id": responder_id_1})
            assert first["nik"] == nik
            with pytest.raises(mysql_store.DuplicateKeyError):
                await db.respondents.insert_one({"_id": responder_id_2, "nik": nik, "reference_code": f"{reference}-2"})
            first_after_duplicate = await db.respondents.find_one({"_id": responder_id_1})
            assert first_after_duplicate["reference_code"] == reference
            assert await db.respondents.find_one({"_id": responder_id_2}) is None

            # Unique reference constraint must also be durable and must not overwrite the first row.
            with pytest.raises(mysql_store.DuplicateKeyError):
                await db.respondents.insert_one({"_id": responder_id_3, "nik": nik2, "reference_code": reference})
            assert await db.respondents.find_one({"_id": responder_id_3}) is None

            # Account emails are canonicalized and unique case-insensitively.
            await db.users.insert_one({"_id": user_id_1, "email": f" IT-{suffix.upper()}@EXAMPLE.COM "})
            with pytest.raises(mysql_store.DuplicateKeyError):
                await db.users.insert_one({"_id": user_id_2, "email": f"it-{suffix}@example.com"})
            user = await db.users.find_one({"_id": user_id_1})
            assert user["email"] == f"it-{suffix}@example.com"
        finally:
            # All test rows removed even when an assertion fails.
            for collection, ids in ((db.respondents, [responder_id_1, responder_id_2, responder_id_3]),
                                    (db.users, [user_id_1, user_id_2])):
                for item_id in ids:
                    try:
                        await collection.delete_one({"_id": item_id})
                    except Exception:
                        pass
            await db.close()
    asyncio.run(scenario())

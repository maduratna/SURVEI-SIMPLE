from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_mysql_schema_persists_unique_constraints():
    schema = (ROOT / "database" / "schema.sql").read_text(encoding="utf-8")
    assert "CREATE TABLE IF NOT EXISTS survey_documents" in schema
    assert "email_unique" in schema and "nik_unique" in schema and "reference_unique" in schema
    assert "uq_survey_users_email" in schema
    assert "uq_survey_respondents_nik" in schema
    assert "uq_survey_respondents_reference" in schema
    assert "GENERATED ALWAYS AS" in schema


def test_reference_sequence_uses_atomic_database_increment():
    core = (ROOT / "backend" / "core.py").read_text(encoding="utf-8")
    store = (ROOT / "backend" / "mysql_store.py").read_text(encoding="utf-8")
    assert "return await db.increment_counter(name)" in core
    assert "LAST_INSERT_ID(1)" in store and "ON DUPLICATE KEY UPDATE" in store
    save_block = store.split("async def _save(self, document, insert=False):", 1)[1].split("async def insert_one", 1)[0]
    assert "ON DUPLICATE KEY UPDATE" not in save_block
    assert "INSERT INTO survey_documents" in save_block and "UPDATE survey_documents SET doc" in save_block


def test_nik_frontend_and_backend_contract():
    frontend = (ROOT / "frontend" / "src" / "pages" / "PublicSurvey.jsx").read_text(encoding="utf-8")
    backend = (ROOT / "backend" / "survey_routes.py").read_text(encoding="utf-8")
    assert "replace(/\\D/g, \"\").slice(0, 16).match(/.{1,4}/g)?.join(\"-\")" in frontend
    assert 'maxLength={19}' in frontend
    assert 're.fullmatch(r"\\d{16}", nik)' in backend
    assert 'nik = re.sub(r"\\D", "", body.nik or "")' in backend


def test_local_launcher_and_environment_templates_exist():
    assert (ROOT / "start.bat").exists()
    assert (ROOT / "backend" / ".env.example").exists()
    assert (ROOT / "frontend" / ".env.example").exists()
    env = (ROOT / "backend" / ".env.example").read_text(encoding="utf-8")
    assert "MYSQL_URL=mysql://" in env
    assert "JWT_SECRET=" in env
    api = (ROOT / "frontend" / "src" / "lib" / "api.js").read_text(encoding="utf-8")
    assert 'http://localhost:8000' in api
    assert 'http://127.0.0.1:8000' not in api

"""Offline tests for the document-compatibility layer (no MySQL server required).

The tests isolate pure query/collection semantics. Real MySQL DDL/transaction tests live in
`test_mysql_integration.py` and are run when MYSQL_TEST_URL is configured.
"""
import asyncio
import copy
import importlib
import os
import sys
import types
import uuid
from datetime import datetime, timezone

# This project pins the real packages. Stub only the connection driver/ID/error classes here
# so these offline unit tests remain runnable in a restricted environment without pip access.
aiomysql_stub = types.ModuleType("aiomysql")
aiomysql_stub.DictCursor = object
sys.modules.setdefault("aiomysql", aiomysql_stub)

bson_stub = types.ModuleType("bson")
class StubObjectId(str):
    def __new__(cls, value=None):
        if value is None:
            value = uuid.uuid4().hex[:24]
        return str.__new__(cls, str(value))
bson_stub.ObjectId = StubObjectId
sys.modules.setdefault("bson", bson_stub)

pymongo_stub = types.ModuleType("pymongo")
errors_stub = types.ModuleType("pymongo.errors")
class StubDuplicateKeyError(Exception):
    pass
errors_stub.DuplicateKeyError = StubDuplicateKeyError
pymongo_stub.errors = errors_stub
pymongo_stub.ReturnDocument = types.SimpleNamespace(BEFORE=False, AFTER=True)
sys.modules.setdefault("pymongo", pymongo_stub)
sys.modules.setdefault("pymongo.errors", errors_stub)
if not hasattr(sys.modules["pymongo"], "ReturnDocument"):
    sys.modules["pymongo"].ReturnDocument = types.SimpleNamespace(BEFORE=False, AFTER=True)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
ms = importlib.import_module("mysql_store")


class FakeDB:
    async def initialize(self):
        return None


class MemoryCollection(ms.Collection):
    def __init__(self, name):
        super().__init__(FakeDB(), name)
        self.documents = {}

    async def _all(self):
        return [copy.deepcopy(doc) for doc in self.documents.values()]

    async def _save(self, document, insert=False):
        normalized = self._normalize(document)
        if insert and str(normalized["_id"]) in self.documents:
            raise RuntimeError("duplicate primary key")
        self.documents[str(normalized["_id"])] = copy.deepcopy(normalized)
        document.clear()
        document.update(normalized)

    async def _delete_id(self, document_id):
        self.documents.pop(str(document_id), None)


def run(coro):
    return asyncio.run(coro)


def test_plain_and_nested_helpers():
    oid = ms.ObjectId("0123456789abcdef01234567")
    assert ms._plain(oid) == str(oid)
    assert ms._plain(datetime(2026, 1, 2, tzinfo=timezone.utc)) == "2026-01-02T00:00:00+00:00"
    doc = {"profile": {"name": "A", "age": 20}}
    assert ms._get(doc, "profile.age") == 20
    ms._set_path(doc, "profile.city.name", "Singaraja")
    assert doc["profile"]["city"]["name"] == "Singaraja"
    ms._unset_path(doc, "profile.age")
    assert "age" not in doc["profile"]


def test_query_operators_and_type_mismatch():
    doc = {"created_at": "2026-10-13T01:00:00+00:00", "name": "SIMPLE Survei", "nested": {"n": 12}}
    assert ms._matches(doc, {"created_at": {"$gte": "2026-10-12", "$lt": "2026-10-14"}})
    assert ms._matches(doc, {"name": {"$regex": "survei", "$options": "i"}})
    assert ms._matches(doc, {"nested.n": {"$in": [10, 12]}})
    assert ms._matches(doc, {"$or": [{"name": "other"}, {"nested.n": {"$gte": 12}}]})
    assert ms._matches(doc, {"$and": [{"nested.n": {"$gt": 10}}, {"name": {"$ne": "other"}}]})
    assert not ms._matches(doc, {"created_at": {"$gt": object()}})
    try:
        ms._matches(doc, {"name": {"$where": "malicious"}})
    except NotImplementedError:
        pass
    else:
        raise AssertionError("Unsupported operators should fail explicitly, not silently match")


def test_crud_projection_sort_paging_and_updates():
    async def scenario():
        coll = MemoryCollection("respondents")
        await coll.insert_one({"_id": "a", "nama": "ANA", "nik": "1234-5678-9012-3456", "score": 2})
        await coll.insert_one({"_id": "b", "nama": "BUDI", "nik": "1234567890123457", "score": 5})
        assert await coll.count_documents({}) == 2
        assert (await coll.find_one({"_id": "a"}))["nik"] == "1234567890123456"
        rows = await coll.find({}, {"nama": 1}).sort("score", -1).skip(0).limit(1).to_list(1)
        assert rows == [{"nama": "BUDI", "_id": "b"}]
        assert coll._project({"_id": "a", "nama": "ANA", "nik": "123"}, {"_id": 0, "nama": 1}) == {"nama": "ANA"}
        assert coll._project({"_id": "a", "nama": "ANA", "nik": "123"}, {"_id": 0}) == {"nama": "ANA", "nik": "123"}
        assert coll._project({"_id": "a", "nama": "ANA", "nik": "123"}, {"_id": 1}) == {"_id": "a"}
        await coll.update_one({"_id": "a"}, {"$set": {"category.grade": "A"}, "$inc": {"score": 1}})
        updated = await coll.find_one({"_id": "a"})
        assert updated["category"]["grade"] == "A" and updated["score"] == 3
        await coll.update_one({"_id": "a"}, {"$unset": {"category.grade": ""}})
        assert "grade" not in (await coll.find_one({"_id": "a"}))["category"]
        result = await coll.replace_one({"_id": "b"}, {"nama": "BUDI UPDATED", "score": 6})
        assert result.matched_count == 1
        assert (await coll.find_one({"_id": "b"}))["nama"] == "BUDI UPDATED"
        deleted = await coll.delete_one({"_id": "a"})
        assert deleted.deleted_count == 1
        assert await coll.count_documents({}) == 1
        deleted_many = await coll.delete_many({})
        assert deleted_many.deleted_count == 1
    run(scenario())


def test_unique_nik_and_email_normalization():
    async def scenario():
        respondents = MemoryCollection("respondents")
        await respondents.create_index("nik", unique=True, partialFilterExpression={"nik": {"$gt": ""}})
        await respondents.insert_one({"_id": "1", "nik": "1111-2222-3333-4444"})
        try:
            await respondents.insert_one({"_id": "2", "nik": "1111222233334444"})
        except ms.DuplicateKeyError:
            pass
        else:
            raise AssertionError("NIK uniqueness must be checked after canonicalization")
        # Empty optional NIKs must not collide.
        await respondents.insert_one({"_id": "3", "nik": ""})
        await respondents.insert_one({"_id": "4", "nik": ""})

        users = MemoryCollection("users")
        await users.create_index("email", unique=True)
        await users.insert_one({"_id": "u1", "email": " ADMIN@EXAMPLE.COM "})
        assert (await users.find_one({"email": "admin@example.com"})) is not None
        try:
            await users.insert_one({"_id": "u2", "email": "admin@example.com"})
        except ms.DuplicateKeyError:
            pass
        else:
            raise AssertionError("User email uniqueness must be case-insensitive")
    run(scenario())


def test_find_one_and_update_after_does_not_deadlock():
    async def scenario():
        coll = MemoryCollection("questions")
        await coll.insert_one({"_id": "q1", "text": "old"})
        # `asyncio.wait_for` guards against re-entering the collection write lock.
        after = await asyncio.wait_for(
            coll.find_one_and_update({"_id": "q1"}, {"$set": {"text": "new"}}, return_document=True),
            timeout=1,
        )
        assert after["text"] == "new"
    run(scenario())


def test_nik_formatter_edge_cases_from_frontend_contract():
    def format_nik(value):
        import re
        digits = re.sub(r"\D", "", value or "")[:16]
        return "-".join(digits[i:i + 4] for i in range(0, len(digits), 4))
    assert format_nik("") == ""
    assert format_nik("123") == "123"
    assert format_nik("12345678") == "1234-5678"
    assert format_nik("3201-1508-1234-5678") == "3201-1508-1234-5678"
    assert format_nik("3201a1508-1234-567890") == "3201-1508-1234-5678"
    assert len(format_nik("1" * 20).replace("-", "")) == 16

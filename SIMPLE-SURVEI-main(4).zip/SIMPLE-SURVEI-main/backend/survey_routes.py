"""Survey config, question builder, and public survey endpoints."""
import re
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from typing import Optional, List
from bson import ObjectId
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError

from core import db, get_current_user, now_utc, serialize, next_sequence, to_wita, format_wita, write_audit
from scoring import compute_respondent_score, category_from_score, SCORING_TYPES

router = APIRouter(prefix="/api", tags=["survey"])


# ---------- helpers ----------
async def get_survey_doc():
    doc = await db.survey.find_one({"_id": "main"})
    return doc


async def get_settings_doc():
    return await db.settings.find_one({"_id": "app"})


async def get_questions_sorted():
    return await db.questions.find().sort("order", 1).to_list(500)


def q_public(q):
    return {
        "id": str(q["_id"]),
        "text": q["text"],
        "type": q["type"],
        "required": q.get("required", False),
        "indicator": q.get("indicator"),
        "options": q.get("options", []),
        "rating_max": q.get("rating_max", 5),
        "rating_labels": q.get("rating_labels", {}),
        "order": q.get("order", 0),
    }


# ---------- PUBLIC ----------
@router.get("/public/survey")
async def public_survey():
    survey = await get_survey_doc()
    settings = await get_settings_doc()
    app_info = {
        "app_name": settings.get("app_name"),
        "instansi": settings.get("instansi"),
        "logo_url": settings.get("logo_url"),
        "website": settings.get("website"),
        "primary_color": settings.get("primary_color"),
    } if settings else {}
    if not survey or survey.get("status") != "open":
        return {"status": "closed", "app": app_info}
    questions = await get_questions_sorted()
    return {
        "status": "open",
        "app": app_info,
        "survey": {
            "title": survey.get("title"),
            "description": survey.get("description"),
            "service_name": survey.get("service_name"),
            "intro_info": survey.get("intro_info"),
            "instructions": survey.get("instructions"),
            "closing_info": survey.get("closing_info"),
            "respondent_fields": survey.get("respondent_fields", {}),
            "pekerjaan_options": survey.get("pekerjaan_options", []),
            "pendidikan_options": survey.get("pendidikan_options", []),
        },
        "questions": [q_public(q) for q in questions],
    }


class SubmitBody(BaseModel):
    nama: Optional[str] = ""
    nik: Optional[str] = ""
    whatsapp: Optional[str] = ""
    email: Optional[str] = ""
    pekerjaan: Optional[str] = ""
    pendidikan: Optional[str] = ""
    answers: List[dict] = []
    suggestion: Optional[str] = ""


def normalize_nama(v: str) -> str:
    return re.sub(r"\s+", " ", (v or "").strip()).upper()


def normalize_wa(v: str) -> str:
    digits = re.sub(r"\D", "", v or "")
    if not digits:
        return ""
    if digits.startswith("0"):
        digits = digits[1:]
    if digits.startswith("62"):
        digits = digits[2:]
    return "+62" + digits


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@router.post("/public/submit")
async def public_submit(body: SubmitBody):
    survey = await get_survey_doc()
    if not survey or survey.get("status") != "open":
        raise HTTPException(status_code=403, detail="Survei sedang ditutup.")

    fields = survey.get("respondent_fields", {})
    nama = normalize_nama(body.nama)
    nik = re.sub(r"\D", "", body.nik or "")
    wa = normalize_wa(body.whatsapp)
    email = (body.email or "").strip().lower()
    pekerjaan = (body.pekerjaan or "").strip()
    pendidikan = (body.pendidikan or "").strip()

    def req(name):
        return fields.get(name, {}).get("required")

    if req("nama") and not nama:
        raise HTTPException(status_code=422, detail="Nama wajib diisi.")
    if req("nik") and not nik:
        raise HTTPException(status_code=422, detail="NIK wajib diisi.")
    if nik and not re.fullmatch(r"\d{16}", nik):
        raise HTTPException(status_code=422, detail="NIK tidak valid. NIK harus terdiri dari 16 digit.")
    if req("whatsapp") and not wa:
        raise HTTPException(status_code=422, detail="Nomor WhatsApp wajib diisi.")
    if email and not EMAIL_RE.match(email):
        raise HTTPException(status_code=422, detail="Format email tidak valid.")
    if req("email") and not email:
        raise HTTPException(status_code=422, detail="Email wajib diisi.")
    if req("pekerjaan") and not pekerjaan:
        raise HTTPException(status_code=422, detail="Pekerjaan wajib dipilih.")
    if req("pendidikan") and not pendidikan:
        raise HTTPException(status_code=422, detail="Pendidikan wajib dipilih.")

    questions = await get_questions_sorted()
    qmap = {str(q["_id"]): q for q in questions}
    answer_map = {str(a.get("question_id")): a.get("value") for a in body.answers}

    for q in questions:
        qid = str(q["_id"])
        if q.get("required") and (qid not in answer_map or answer_map[qid] in (None, "", [])):
            raise HTTPException(status_code=422, detail="Mohon lengkapi semua pertanyaan yang wajib diisi.")

    clean_answers = []
    for qid, val in answer_map.items():
        if qid in qmap:
            clean_answers.append({"question_id": qid, "indicator": qmap[qid].get("indicator"),
                                  "type": qmap[qid].get("type"), "value": val})

    score, ind_pct = compute_respondent_score(clean_answers, qmap, survey.get("categories"))
    category = category_from_score(score, survey.get("categories"))

    now = now_utc()
    w = to_wita(now)
    seq = await next_sequence("reference")
    date_part = w.strftime("%d%m%y")
    reference_code = f"AS{seq:03d}-{date_part}"
    registration_number = f"REG-{w.strftime('%y%m%d')}-{seq:04d}"

    doc = {
        "nama": nama, "nik": nik, "whatsapp": wa, "email": email,
        "pekerjaan": pekerjaan, "pendidikan": pendidikan,
        "answers": clean_answers,
        "suggestion": (body.suggestion or "").strip(),
        "score": score,
        "category": category,
        "indicator_scores": ind_pct,
        "reference_code": reference_code,
        "registration_number": registration_number,
        "created_at": now.isoformat(),
        "submitted_at": now.isoformat(),
        "updated_at": now.isoformat(),
    }
    try:
        await db.respondents.insert_one(doc)
    except DuplicateKeyError as exc:
        if "reference" in str(exc).lower():
            # This is a sequence/reference collision, not a duplicate NIK. Avoid a misleading
            # validation error; log/inspect server details and allow a clean retry by the user.
            raise HTTPException(status_code=503, detail="Kode referensi sedang mengalami konflik. Silakan kirim ulang beberapa saat lagi.")
        raise HTTPException(status_code=409, detail="NIK tersebut sudah terdaftar pada survei ini.")

    return {
        "reference_code": reference_code,
        "registration_number": registration_number,
        "submitted_at": now.isoformat(),
        "submitted_at_formatted": format_wita(now),
        "closing_info": survey.get("closing_info"),
    }


# ---------- ADMIN: SURVEY CONFIG ----------
@router.get("/survey")
async def get_survey(user: dict = Depends(get_current_user)):
    doc = await get_survey_doc()
    if not doc:
        raise HTTPException(status_code=404, detail="Konfigurasi survei tidak ditemukan.")
    doc["id"] = doc.pop("_id")
    return doc


class SurveyUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    service_name: Optional[str] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    status: Optional[str] = None
    intro_info: Optional[str] = None
    instructions: Optional[str] = None
    closing_info: Optional[str] = None
    categories: Optional[list] = None
    respondent_fields: Optional[dict] = None
    pekerjaan_options: Optional[list] = None
    pendidikan_options: Optional[list] = None
    scale: Optional[dict] = None


@router.put("/survey")
async def update_survey(body: SurveyUpdate, user: dict = Depends(get_current_user)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if "status" in updates and updates["status"] not in ("open", "closed"):
        raise HTTPException(status_code=422, detail="Status tidak valid.")
    updates["updated_at"] = now_utc().isoformat()
    await db.survey.update_one({"_id": "main"}, {"$set": updates})
    await write_audit(user, "edit_survey", {"fields": list(updates.keys())})
    doc = await get_survey_doc()
    doc["id"] = doc.pop("_id")
    return doc


# ---------- ADMIN: QUESTIONS ----------
@router.get("/questions")
async def list_questions(user: dict = Depends(get_current_user)):
    qs = await get_questions_sorted()
    return [serialize(q) for q in qs]


class QuestionBody(BaseModel):
    text: str
    type: str
    required: bool = False
    indicator: Optional[str] = ""
    weight: float = 1
    options: list = []
    rating_max: int = 5
    rating_labels: dict = {}


VALID_TYPES = {"single_choice", "multiple_choice", "rating_5", "rating_4",
               "custom_rating", "yes_no", "text", "textarea"}


@router.post("/questions")
async def create_question(body: QuestionBody, user: dict = Depends(get_current_user)):
    if body.type not in VALID_TYPES:
        raise HTTPException(status_code=422, detail="Jenis pertanyaan tidak valid.")
    count = await db.questions.count_documents({})
    doc = body.model_dump()
    doc["order"] = count
    doc["created_at"] = now_utc().isoformat()
    res = await db.questions.insert_one(doc)
    await write_audit(user, "add_question", {"text": body.text[:60]})
    return serialize(await db.questions.find_one({"_id": res.inserted_id}))


@router.put("/questions/reorder")
async def reorder_questions(payload: dict, user: dict = Depends(get_current_user)):
    ids = payload.get("ids", [])
    for i, qid in enumerate(ids):
        await db.questions.update_one({"_id": ObjectId(qid)}, {"$set": {"order": i}})
    await write_audit(user, "reorder_questions")
    return {"ok": True}


@router.put("/questions/{qid}")
async def update_question(qid: str, body: QuestionBody, user: dict = Depends(get_current_user)):
    if body.type not in VALID_TYPES:
        raise HTTPException(status_code=422, detail="Jenis pertanyaan tidak valid.")
    res = await db.questions.find_one_and_update(
        {"_id": ObjectId(qid)}, {"$set": body.model_dump()},
        return_document=ReturnDocument.AFTER)
    if not res:
        raise HTTPException(status_code=404, detail="Pertanyaan tidak ditemukan.")
    await write_audit(user, "edit_question", {"id": qid})
    return serialize(res)


@router.post("/questions/{qid}/duplicate")
async def duplicate_question(qid: str, user: dict = Depends(get_current_user)):
    src = await db.questions.find_one({"_id": ObjectId(qid)})
    if not src:
        raise HTTPException(status_code=404, detail="Pertanyaan tidak ditemukan.")
    count = await db.questions.count_documents({})
    src.pop("_id")
    src["order"] = count
    src["text"] = src.get("text", "") + " (Salinan)"
    src["created_at"] = now_utc().isoformat()
    res = await db.questions.insert_one(src)
    await write_audit(user, "duplicate_question", {"id": qid})
    return serialize(await db.questions.find_one({"_id": res.inserted_id}))


@router.delete("/questions/{qid}")
async def delete_question(qid: str, user: dict = Depends(get_current_user)):
    res = await db.questions.delete_one({"_id": ObjectId(qid)})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Pertanyaan tidak ditemukan.")
    await write_audit(user, "delete_question", {"id": qid})
    return {"ok": True}

"""PDF and Excel report generation with charts."""
import io
from datetime import datetime
from pathlib import Path
from fastapi import APIRouter, Depends, Query
from fastapi.responses import StreamingResponse
from typing import Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Image as RLImage, PageBreak)
from reportlab.lib.enums import TA_CENTER, TA_LEFT

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from core import db, get_current_user, now_utc, to_wita, format_wita
from admin_routes import period_range, gather_stats, range_query

router = APIRouter(prefix="/api/reports", tags=["reports"])

LOGO_PATH = Path("/app/frontend/public/assets/logo.jpg")
RED = colors.HexColor("#C81E1E")
DARK = colors.HexColor("#0F172A")
GRAY = colors.HexColor("#CBD5E1")
LIGHT = colors.HexColor("#F8FAFC")
RED_BG = colors.HexColor("#FEF2F2")

BRAND = "#C81E1E"
BLUE = "#2563EB"
GREEN = "#059669"
AMBER = "#D97706"
PURPLE = "#7C3AED"
SLATE = "#64748B"
PALETTE = [BRAND, BLUE, GREEN, AMBER, PURPLE, SLATE, "#0D9488", "#DB2777", "#65A30D"]


# ---------------- matplotlib chart builders ----------------
def _new_fig(w=7.6, h=3.6):
    fig, ax = plt.subplots(figsize=(w, h), dpi=160)
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.tick_params(labelsize=9, colors="#334155")
    return fig, ax


def _fig_to_image(fig, width_mm=176):
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", bbox_inches="tight", facecolor="white")
    plt.close(fig)
    buf.seek(0)
    img = RLImage(buf)
    ratio = img.imageHeight / img.imageWidth
    img.drawWidth = width_mm * mm
    img.drawHeight = width_mm * ratio * mm
    return img


def chart_indicators(stats):
    data = stats.get("indicators") or []
    if not data:
        return None
    labels = [d["indicator"] for d in data]
    values = [d["score"] for d in data]
    h = max(2.8, 0.42 * len(labels) + 1)
    fig, ax = _new_fig(7.6, h)
    cols = [GREEN if v >= 76 else AMBER if v >= 65 else "#DC2626" for v in values]
    ax.barh(range(len(labels)), values, color=cols, height=0.62)
    ax.set_yticks(range(len(labels)), labels=labels, fontsize=9)
    ax.invert_yaxis()
    ax.set_xlim(0, 100)
    ax.axvline(76.61, color=BLUE, linestyle="--", linewidth=1)
    ax.set_xlabel("Nilai (0–100)", fontsize=9, color="#475569")
    for i, v in enumerate(values):
        ax.text(v + 1, i, f"{v:.2f}", va="center", fontsize=8.5, color="#0F172A", fontweight="bold")
    ax.set_title("Nilai Per Unsur Pelayanan", fontsize=11, fontweight="bold", color="#0F172A", loc="left")
    return _fig_to_image(fig)


def chart_pekerjaan(stats):
    data = stats.get("pekerjaan") or []
    if not data:
        return None
    labels = [d["name"] for d in data]
    values = [d["value"] for d in data]
    fig, ax = _new_fig(7.6, 3.4)
    wedges, texts, autotexts = ax.pie(
        values, labels=None, autopct="%1.0f%%", pctdistance=0.78,
        colors=[PALETTE[i % len(PALETTE)] for i in range(len(values))],
        wedgeprops=dict(width=0.42, edgecolor="white", linewidth=1.5),
        textprops=dict(fontsize=9, color="white", fontweight="bold"))
    ax.legend(wedges, labels, loc="center left", bbox_to_anchor=(1.0, 0.5), fontsize=8.5, frameon=False)
    ax.set_title("Distribusi Pekerjaan Responden", fontsize=11, fontweight="bold", color="#0F172A", loc="left")
    return _fig_to_image(fig, 160)


def chart_pendidikan(stats):
    data = stats.get("pendidikan") or []
    if not data:
        return None
    labels = [d["name"] for d in data]
    values = [d["value"] for d in data]
    fig, ax = _new_fig(7.6, 3.0)
    bars = ax.bar(labels, values, color=[PALETTE[i % len(PALETTE)] for i in range(len(values))], width=0.6)
    for b, v in zip(bars, values):
        ax.text(b.get_x() + b.get_width() / 2, v, str(v), ha="center", va="bottom",
                fontsize=9, fontweight="bold", color="#0F172A")
    ax.set_ylabel("Jumlah", fontsize=9, color="#475569")
    ax.set_title("Distribusi Pendidikan Responden", fontsize=11, fontweight="bold", color="#0F172A", loc="left")
    ax.grid(axis="y", color="#E2E8F0", linewidth=0.8)
    ax.set_axisbelow(True)
    return _fig_to_image(fig)


def chart_rating(stats):
    data = stats.get("rating_distribution") or []
    if not data:
        return None
    labels = [f"Nilai {d['name']}" for d in data]
    values = [d["value"] for d in data]
    cols = ["#DC2626", "#F97316", "#D97706", "#65A30D", "#059669", BLUE, PURPLE]
    fig, ax = _new_fig(7.6, 3.0)
    bars = ax.bar(labels, values, color=cols[:len(values)], width=0.55)
    for b, v in zip(bars, values):
        ax.text(b.get_x() + b.get_width() / 2, v, str(v), ha="center", va="bottom",
                fontsize=9, fontweight="bold", color="#0F172A")
    ax.set_ylabel("Jumlah Jawaban", fontsize=9, color="#475569")
    ax.set_title("Distribusi Nilai Rating", fontsize=11, fontweight="bold", color="#0F172A", loc="left")
    ax.grid(axis="y", color="#E2E8F0", linewidth=0.8)
    ax.set_axisbelow(True)
    return _fig_to_image(fig)


def chart_trend(stats):
    data = stats.get("trend") or []
    if not data:
        return None
    labels = [d["date"] for d in data]
    values = [d["value"] for d in data]
    fig, ax = _new_fig(7.6, 3.0)
    ax.plot(labels, values, color=BRAND, marker="o", linewidth=2.2, markersize=4)
    ax.fill_between(labels, values, color=BRAND, alpha=0.10)
    ax.set_ylabel("Jumlah Responden", fontsize=9, color="#475569")
    ax.set_title("Tren Jumlah Responden", fontsize=11, fontweight="bold", color="#0F172A", loc="left")
    ax.grid(color="#E2E8F0", linewidth=0.8)
    ax.set_axisbelow(True)
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right", fontsize=8)
    return _fig_to_image(fig)


def chart_ikm_trend(stats):
    data = stats.get("ikm_trend") or []
    if len(data) < 2:
        return None
    labels = [d["date"] for d in data]
    values = [d["value"] for d in data]
    fig, ax = _new_fig(7.6, 3.0)
    ax.plot(labels, values, color=BLUE, marker="o", linewidth=2.2, markersize=4)
    ax.fill_between(labels, values, color=BLUE, alpha=0.10)
    ax.set_ylim(0, 100)
    ax.set_ylabel("Nilai IKM", fontsize=9, color="#475569")
    ax.set_title("Tren Nilai IKM", fontsize=11, fontweight="bold", color="#0F172A", loc="left")
    ax.grid(color="#E2E8F0", linewidth=0.8)
    ax.set_axisbelow(True)
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right", fontsize=8)
    return _fig_to_image(fig)


# ---------------- shared context ----------------
async def _context(period, start, end, user):
    survey = await db.survey.find_one({"_id": "main"})
    settings = await db.settings.find_one({"_id": "app"})
    start_iso, end_iso, label = period_range(period, start, end)
    stats = await gather_stats(start_iso, end_iso)
    return survey, settings, label, stats, start_iso, end_iso


def _styled_table(rows, col_widths, header_bg=RED, header_fg=colors.white, font_size=9):
    t = Table(rows, colWidths=col_widths, repeatRows=1)
    style = [
        ("GRID", (0, 0), (-1, -1), 0.6, GRAY),
        ("BACKGROUND", (0, 0), (-1, 0), header_bg),
        ("TEXTCOLOR", (0, 0), (-1, 0), header_fg),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), font_size),
        ("TEXTCOLOR", (0, 1), (-1, -1), DARK),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8), ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]
    t.setStyle(TableStyle(style))
    return t


@router.get("/pdf")
async def report_pdf(period: str = "all", start: Optional[str] = None,
                     end: Optional[str] = None, user: dict = Depends(get_current_user)):
    survey, settings, label, stats, _, _ = await _context(period, start, end, user)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, topMargin=16 * mm, bottomMargin=18 * mm,
                            leftMargin=16 * mm, rightMargin=16 * mm, title="Laporan AKU Online")
    styles = getSampleStyleSheet()
    h_center = ParagraphStyle("hc", parent=styles["Title"], textColor=DARK, fontSize=15, alignment=TA_CENTER)
    sub = ParagraphStyle("sub", parent=styles["Normal"], alignment=TA_CENTER, fontSize=10,
                         textColor=colors.HexColor("#475569"))
    section = ParagraphStyle("sec", parent=styles["Heading2"], textColor=RED, fontSize=12,
                             spaceBefore=12, spaceAfter=6, fontName="Helvetica-Bold")
    normal = ParagraphStyle("n", parent=styles["Normal"], fontSize=9.5, leading=14, textColor=DARK)
    header_style = ParagraphStyle("hd", parent=styles["Normal"], fontSize=10, textColor=DARK, leading=13)

    elements = []
    # ---- header / kop ----
    header_cells = []
    if LOGO_PATH.exists():
        try:
            header_cells.append(RLImage(str(LOGO_PATH), width=22 * mm, height=22 * mm))
        except Exception:
            header_cells.append(Paragraph("", normal))
    else:
        header_cells.append(Paragraph("", normal))
    header_text = Paragraph(
        f"<b><font size=13>{settings.get('instansi','')}</font></b><br/>"
        f"<b>{settings.get('app_name','')}</b><br/>"
        f"<font size=8 color='#475569'>{settings.get('address','')}<br/>{settings.get('website','')}</font>",
        header_style)
    header_cells.append(header_text)
    ht = Table([[header_cells[0], header_cells[1]]], colWidths=[26 * mm, 150 * mm])
    ht.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    elements.append(ht)
    elements.append(Spacer(1, 6))
    elements.append(Table([[""]], colWidths=[176 * mm], style=TableStyle(
        [("LINEBELOW", (0, 0), (-1, -1), 2, RED), ("LINEBELOW", (0, 0), (-1, -1), 0.6, DARK)])))
    elements.append(Spacer(1, 10))

    elements.append(Paragraph("LAPORAN HASIL SURVEI KEPUASAN MASYARAKAT", h_center))
    elements.append(Paragraph(f"{survey.get('title','')} &mdash; Periode: {label}", sub))
    elements.append(Spacer(1, 12))

    # ---- ringkasan ----
    cat = stats["category"]["label"] if stats["category"] else "-"
    ikm = stats["ikm"] if stats["ikm"] is not None else "-"
    summary_rows = [
        ["INDIKATOR", "NILAI"],
        ["Total Responden (Keseluruhan)", str(stats["grand_total"])],
        ["Responden (Periode Terpilih)", str(stats["total"])],
        ["Nilai IKM/SKM", str(ikm)],
        ["Kategori Mutu Pelayanan", cat],
        ["Jumlah Saran/Masukan", str(stats["suggestions_count"])],
    ]
    elements.append(Paragraph("1. Ringkasan", section))
    elements.append(_styled_table(summary_rows, [90 * mm, 86 * mm]))

    # ---- indikator table + chart ----
    elements.append(Paragraph("2. Nilai Per Unsur / Indikator", section))
    ind_rows = [["UNSUR PELAYANAN", "NILAI", "RESPONDEN"]]
    for ind in stats["indicators"]:
        ind_rows.append([ind["indicator"], f"{ind['score']:.2f}", str(ind["count"])])
    if len(ind_rows) == 1:
        ind_rows.append(["Belum ada data", "-", "-"])
    it = _styled_table(ind_rows, [116 * mm, 30 * mm, 30 * mm])
    it.setStyle(TableStyle([("ALIGN", (1, 0), (-1, -1), "CENTER")]))
    elements.append(it)
    img = chart_indicators(stats)
    if img:
        elements.append(Spacer(1, 8))
        elements.append(img)

    # ---- charts page ----
    chart_list = [chart_trend(stats), chart_pekerjaan(stats), chart_pendidikan(stats),
                  chart_rating(stats), chart_ikm_trend(stats)]
    chart_list = [c for c in chart_list if c]
    if chart_list:
        elements.append(PageBreak())
        elements.append(Paragraph("3. Visualisasi Data", section))
        for c in chart_list:
            elements.append(c)
            elements.append(Spacer(1, 10))

    # ---- distribution tables ----
    def dist_table(title, data):
        elements.append(Paragraph(title, section))
        rows = [["KATEGORI", "JUMLAH"]] + [[d["name"], str(d["value"])] for d in data]
        if len(rows) == 1:
            rows.append(["Belum ada data", "-"])
        tb = _styled_table(rows, [130 * mm, 46 * mm])
        tb.setStyle(TableStyle([("ALIGN", (1, 0), (1, -1), "CENTER")]))
        elements.append(tb)

    n_sec = 4
    dist_table(f"{n_sec}. Distribusi Pekerjaan", stats["pekerjaan"]); n_sec += 1
    dist_table(f"{n_sec}. Distribusi Pendidikan", stats["pendidikan"]); n_sec += 1

    # ---- conclusion ----
    elements.append(Paragraph(f"{n_sec}. Kesimpulan", section)); n_sec += 1
    concl = (f"Berdasarkan {stats['total']} responden pada periode {label}, "
             f"nilai IKM/SKM adalah <b>{ikm}</b> dengan kategori <b>{cat}</b>.")
    if stats["highest"]:
        concl += f" Unsur tertinggi adalah <b>{stats['highest']['indicator']}</b> ({stats['highest']['score']})."
    if stats["lowest"]:
        concl += f" Unsur yang perlu ditingkatkan adalah <b>{stats['lowest']['indicator']}</b> ({stats['lowest']['score']})."
    elements.append(Paragraph(concl, normal))

    # ---- suggestions ----
    if stats["suggestions"]:
        elements.append(Paragraph(f"{n_sec}. Saran &amp; Masukan", section))
        for s in stats["suggestions"][:30]:
            elements.append(Paragraph(f"&bull; <b>[{s['reference_code']}]</b> {s['text']}", normal))

    elements.append(Spacer(1, 18))
    gen = Paragraph(
        f"<font size=8 color='#64748B'>Dibuat pada: {format_wita(now_utc())} &nbsp;|&nbsp; "
        f"Oleh: {user.get('name', user.get('email'))}<br/>{settings.get('pdf_footer','')}</font>",
        ParagraphStyle("f", parent=styles["Normal"], alignment=TA_LEFT))
    elements.append(gen)

    def footer(canvas, docu):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#64748B"))
        canvas.setStrokeColor(GRAY)
        canvas.line(16 * mm, 14 * mm, 195 * mm, 14 * mm)
        canvas.drawRightString(195 * mm, 10 * mm, f"Halaman {docu.page}")
        canvas.restoreState()

    doc.build(elements, onFirstPage=footer, onLaterPages=footer)
    buf.seek(0)
    fname = f"Laporan-SKM-{to_wita(now_utc()).strftime('%Y%m%d-%H%M')}.pdf"
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f'attachment; filename="{fname}"'})


@router.get("/excel")
async def report_excel(period: str = "all", start: Optional[str] = None,
                       end: Optional[str] = None, user: dict = Depends(get_current_user)):
    survey, settings, label, stats, start_iso, end_iso = await _context(period, start, end, user)

    wb = Workbook()
    header_fill = PatternFill("solid", fgColor="C81E1E")
    header_font = Font(bold=True, color="FFFFFF")
    bold = Font(bold=True)

    def style_header(ws, row, ncols):
        for c in range(1, ncols + 1):
            cell = ws.cell(row=row, column=c)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")

    def autofit(ws, widths):
        for i, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(i)].width = w

    ws = wb.active
    ws.title = "Ringkasan"
    ws["A1"] = settings.get("instansi", "")
    ws["A1"].font = Font(bold=True, size=14, color="C81E1E")
    ws["A2"] = f"{survey.get('title','')} - Periode: {label}"
    rows = [
        ("Total Responden (keseluruhan)", stats["grand_total"]),
        ("Responden pada periode", stats["total"]),
        ("Nilai IKM/SKM", stats["ikm"] if stats["ikm"] is not None else "-"),
        ("Kategori", stats["category"]["label"] if stats["category"] else "-"),
        ("Jumlah Saran", stats["suggestions_count"]),
        ("Dibuat pada", format_wita(now_utc())),
    ]
    r = 4
    for k, v in rows:
        ws.cell(row=r, column=1, value=k).font = bold
        ws.cell(row=r, column=2, value=v)
        r += 1
    autofit(ws, [34, 40])

    ws2 = wb.create_sheet("Data Responden")
    cols = ["No", "Reference", "Registrasi", "Tanggal", "Nama", "NIK", "WhatsApp",
            "Email", "Pekerjaan", "Pendidikan", "Score", "Kategori"]
    ws2.append(cols)
    style_header(ws2, 1, len(cols))
    resp = await db.respondents.find(range_query(start_iso, end_iso)).sort("created_at", -1).to_list(100000)
    for i, d in enumerate(resp, start=1):
        ws2.append([
            i, d.get("reference_code"), d.get("registration_number"),
            format_wita(datetime.fromisoformat(d["created_at"])),
            d.get("nama"), d.get("nik"), d.get("whatsapp"), d.get("email"),
            d.get("pekerjaan"), d.get("pendidikan"), d.get("score"),
            d.get("category", {}).get("label") if d.get("category") else "-",
        ])
    autofit(ws2, [5, 14, 16, 24, 24, 20, 16, 24, 16, 12, 8, 14])
    ws2.freeze_panes = "A2"
    ws2.auto_filter.ref = f"A1:{get_column_letter(len(cols))}1"

    ws3 = wb.create_sheet("Jawaban")
    questions = await db.questions.find().sort("order", 1).to_list(500)
    qmap = {str(q["_id"]): q for q in questions}
    jcols = ["Reference", "Unsur", "Pertanyaan", "Jawaban"]
    ws3.append(jcols)
    style_header(ws3, 1, len(jcols))
    for d in resp:
        for a in d.get("answers", []):
            q = qmap.get(a.get("question_id"))
            ws3.append([d.get("reference_code"), a.get("indicator"),
                        q.get("text") if q else "-", a.get("value")])
    autofit(ws3, [14, 28, 60, 12])
    ws3.freeze_panes = "A2"

    ws4 = wb.create_sheet("Analitik")
    ws4.append(["Unsur Pelayanan", "Nilai", "Jumlah Responden"])
    style_header(ws4, 1, 3)
    for ind in stats["indicators"]:
        ws4.append([ind["indicator"], ind["score"], ind["count"]])
    autofit(ws4, [40, 12, 18])
    ws4.freeze_panes = "A2"

    ws5 = wb.create_sheet("IKM")
    ws5.append(["Keterangan", "Nilai"])
    style_header(ws5, 1, 2)
    ws5.append(["Nilai IKM/SKM", stats["ikm"] if stats["ikm"] is not None else "-"])
    ws5.append(["Kategori", stats["category"]["label"] if stats["category"] else "-"])
    ws5.append(["Unsur Tertinggi", f"{stats['highest']['indicator']} ({stats['highest']['score']})" if stats["highest"] else "-"])
    ws5.append(["Unsur Terendah", f"{stats['lowest']['indicator']} ({stats['lowest']['score']})" if stats["lowest"] else "-"])
    autofit(ws5, [28, 40])

    ws6 = wb.create_sheet("Statistik")
    ws6.append(["Distribusi Pekerjaan", ""])
    style_header(ws6, 1, 2)
    for d in stats["pekerjaan"]:
        ws6.append([d["name"], d["value"]])
    start_row = ws6.max_row + 2
    ws6.cell(row=start_row, column=1, value="Distribusi Pendidikan").font = bold
    for d in stats["pendidikan"]:
        ws6.append([d["name"], d["value"]])
    autofit(ws6, [30, 12])

    ws7 = wb.create_sheet("Saran")
    ws7.append(["Reference", "Saran & Masukan"])
    style_header(ws7, 1, 2)
    for s in stats["suggestions"]:
        ws7.append([s["reference_code"], s["text"]])
    autofit(ws7, [16, 80])
    ws7.freeze_panes = "A2"

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"Laporan-SKM-{to_wita(now_utc()).strftime('%Y%m%d-%H%M')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'})

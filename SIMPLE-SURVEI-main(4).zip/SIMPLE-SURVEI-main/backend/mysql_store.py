"""MySQL-backed compatibility persistence for SIMPLE-SURVEI.

The API keeps its existing document-oriented data shape to minimize UI/API changes,
while MySQL enforces durable unique constraints and atomic reference counters.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
from copy import deepcopy
from datetime import date, datetime
from urllib.parse import unquote, urlparse

import aiomysql
from bson import ObjectId
from pymongo.errors import DuplicateKeyError


def _plain(value):
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, dict):
        return {key: _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    return value


def _get(document, key):
    current = document
    for part in key.split("."):
        if not isinstance(current, dict):
            return None
        current = current.get(part)
    return current


def _set_path(document, key, value):
    current = document
    parts = key.split(".")
    for part in parts[:-1]:
        child = current.get(part)
        if not isinstance(child, dict):
            child = {}
            current[part] = child
        current = child
    current[parts[-1]] = deepcopy(value)


def _unset_path(document, key):
    current = document
    parts = key.split(".")
    for part in parts[:-1]:
        current = current.get(part)
        if not isinstance(current, dict):
            return
    current.pop(parts[-1], None)


def _cmp(actual, expected):
    if isinstance(expected, dict):
        for op, value in expected.items():
            try:
                if op == "$gte" and not (actual is not None and actual >= value):
                    return False
                if op == "$gt" and not (actual is not None and actual > value):
                    return False
                if op == "$lt" and not (actual is not None and actual < value):
                    return False
                if op == "$lte" and not (actual is not None and actual <= value):
                    return False
            except TypeError:
                return False
            if op == "$ne" and _plain(actual) == _plain(value):
                return False
            if op == "$in" and not any(_plain(actual) == _plain(item) for item in value):
                return False
            if op == "$regex":
                flags = re.I if expected.get("$options") == "i" else 0
                if actual is None or not re.search(str(value), str(actual), flags):
                    return False
            if op == "$options":
                continue
            if op not in {"$gte", "$gt", "$lt", "$lte", "$ne", "$in", "$regex", "$options"}:
                raise NotImplementedError(f"Operator query MongoDB belum didukung: {op}")
        return True
    return _plain(actual) == _plain(expected)


def _matches(document, query):
    for key, expected in (query or {}).items():
        if key == "$or":
            if not any(_matches(document, clause) for clause in expected):
                return False
        elif key == "$and":
            if not all(_matches(document, clause) for clause in expected):
                return False
        elif key.startswith("$"):
            raise NotImplementedError(f"Operator query MongoDB belum didukung: {key}")
        elif not _cmp(_get(document, key), expected):
            return False
    return True


class InsertOneResult:
    def __init__(self, inserted_id):
        self.inserted_id = inserted_id


class InsertManyResult:
    def __init__(self, inserted_ids):
        self.inserted_ids = inserted_ids


class UpdateResult:
    def __init__(self, matched=0, modified=0, upserted=None):
        self.matched_count = matched
        self.modified_count = modified
        self.upserted_id = upserted


class DeleteResult:
    def __init__(self, count=0):
        self.deleted_count = count


class Cursor:
    def __init__(self, collection, query=None, projection=None):
        self.collection = collection
        self.query = query or {}
        self.projection = projection
        self.sort_spec = []
        self.offset = 0
        self.max_items = None
        self._iter = None

    def sort(self, key, direction=1):
        self.sort_spec = key if isinstance(key, list) else [(key, direction)]
        return self

    def skip(self, count):
        self.offset = max(0, int(count))
        return self

    def limit(self, count):
        self.max_items = max(0, int(count))
        return self

    async def to_list(self, length=None):
        documents = [doc for doc in await self.collection._all() if _matches(doc, self.query)]
        for key, direction in reversed(self.sort_spec):
            documents.sort(key=lambda doc: (_get(doc, key) is None, _get(doc, key)), reverse=direction < 0)
        documents = documents[self.offset:]
        cap = self.max_items if self.max_items is not None else length
        if cap is not None:
            documents = documents[:max(0, int(cap))]
        return [self.collection._project(doc, self.projection) for doc in documents]

    def __aiter__(self):
        self._iter = None
        return self

    async def __anext__(self):
        if self._iter is None:
            self._iter = iter(await self.to_list())
        try:
            return next(self._iter)
        except StopIteration:
            raise StopAsyncIteration


class Collection:
    def __init__(self, database, name):
        self.db = database
        self.name = name
        self.indexes = []
        self._write_lock = asyncio.Lock()

    async def _all(self):
        await self.db.initialize()
        async with self.db.pool.acquire() as connection:
            async with connection.cursor(aiomysql.DictCursor) as cursor:
                await cursor.execute(
                    "SELECT doc FROM survey_documents WHERE collection_name=%s", (self.name,)
                )
                rows = await cursor.fetchall()
        documents = []
        for row in rows:
            try:
                value = row["doc"]
                documents.append(value if isinstance(value, dict) else json.loads(value))
            except (TypeError, ValueError, KeyError):
                # Corrupt rows should not crash every listing; integrity tests should detect them.
                continue
        return documents

    def _project(self, doc, projection):
        if not projection:
            return deepcopy(doc)
        # Mongo-style inclusion projections may exclude _id while selecting other fields.
        include_fields = [key for key, value in projection.items() if value and key != "_id"]
        has_non_id_exclusion = any(value == 0 and key != "_id" for key, value in projection.items())
        if has_non_id_exclusion or (set(projection) == {"_id"} and projection.get("_id") == 0):
            result = deepcopy(doc)
            for key, value in projection.items():
                if value == 0:
                    if "." not in key:
                        result.pop(key, None)
                    else:
                        _unset_path(result, key)
            return result
        result = {key: _get(doc, key) for key in include_fields if _get(doc, key) is not None}
        if projection.get("_id", 1) and "_id" in doc:
            result["_id"] = doc["_id"]
        return result

    def find(self, query=None, projection=None):
        return Cursor(self, query, projection)

    async def find_one(self, query=None, projection=None):
        for document in await self._all():
            if _matches(document, query or {}):
                return self._project(document, projection)
        return None

    async def count_documents(self, query):
        return sum(1 for doc in await self._all() if _matches(doc, query or {}))

    async def create_index(self, key, unique=False, **kwargs):
        keys = [key] if isinstance(key, str) else [item[0] for item in key]
        if unique and (keys, kwargs.get("partialFilterExpression")) not in self.indexes:
            self.indexes.append((keys, kwargs.get("partialFilterExpression")))
        # Durable unique indexes are created centrally by Database.initialize().
        return "_".join(keys)

    async def _check_unique(self, document, excluding=None):
        for keys, partial in self.indexes:
            if partial and not _matches(document, partial):
                continue
            values = tuple(_get(document, key) for key in keys)
            if any(value is None or value == "" for value in values):
                continue
            for other in await self._all():
                if excluding is not None and str(other.get("_id")) == str(excluding):
                    continue
                if partial and not _matches(other, partial):
                    continue
                if tuple(_get(other, key) for key in keys) == values:
                    raise DuplicateKeyError(f"Duplicate value for unique index {keys}")

    def _normalize(self, document):
        result = deepcopy(document)
        if self.name == "respondents" and result.get("nik"):
            result["nik"] = re.sub(r"\D", "", str(result["nik"]))
        if self.name == "users" and result.get("email"):
            result["email"] = str(result["email"]).strip().lower()
        return result

    async def _save(self, document, insert=False):
        """Persist a document without allowing a secondary unique-key conflict to overwrite a row.

        Inserts use plain INSERT. Existing rows use UPDATE by the composite primary key. Never use
        implicit duplicate-key upsert here: that could turn a duplicate NIK into an overwrite of
        another respondent because NIK/reference are also unique keys.
        """
        await self.db.initialize()
        doc = self._normalize(document)
        payload = json.dumps(_plain(doc), ensure_ascii=False, separators=(",", ":"))
        try:
            async with self.db.pool.acquire() as connection:
                async with connection.cursor() as cursor:
                    if insert:
                        await cursor.execute(
                            "INSERT INTO survey_documents (collection_name, document_id, doc) VALUES (%s,%s,%s)",
                            (self.name, str(doc["_id"]), payload),
                        )
                    else:
                        await cursor.execute(
                            "UPDATE survey_documents SET doc=%s WHERE collection_name=%s AND document_id=%s",
                            (payload, self.name, str(doc["_id"])),
                        )
                        if cursor.rowcount == 0:
                            # MySQL reports rowcount=0 for a no-op UPDATE as well as a missing row.
                            await cursor.execute(
                                "SELECT 1 FROM survey_documents WHERE collection_name=%s AND document_id=%s",
                                (self.name, str(doc["_id"])),
                            )
                            if await cursor.fetchone() is None:
                                raise RuntimeError(
                                    f"Dokumen {self.name}/{doc['_id']} tidak ditemukan ketika diperbarui."
                                )
                await connection.commit()
        except Exception as error:
            # MySQL duplicate entry is errno 1062. Preserve the constraint name in the message
            # so public endpoints can distinguish duplicate NIK from reference-code collisions.
            if getattr(error, "args", ()) and error.args[0] == 1062:
                detail = str(error)
                if "uq_survey_respondents_nik" in detail:
                    message = "Duplicate NIK on uq_survey_respondents_nik"
                elif "uq_survey_respondents_reference" in detail:
                    message = "Duplicate reference code on uq_survey_respondents_reference"
                elif "uq_survey_users_email" in detail:
                    message = "Duplicate admin email on uq_survey_users_email"
                else:
                    message = "Nilai unik sudah digunakan."
                raise DuplicateKeyError(message) from error
            raise
        document.clear()
        document.update(doc)

    async def insert_one(self, document):
        doc = self._normalize(document)
        doc["_id"] = str(doc.get("_id") or ObjectId())
        async with self._write_lock:
            await self._check_unique(doc)
            await self._save(doc, insert=True)
        return InsertOneResult(doc["_id"])

    async def insert_many(self, documents):
        inserted_ids = []
        for document in documents:
            inserted_ids.append((await self.insert_one(document)).inserted_id)
        return InsertManyResult(inserted_ids)

    async def update_one(self, query, update, upsert=False):
        async with self._write_lock:
            doc = await self.find_one(query)
            if doc is None:
                if not upsert:
                    return UpdateResult()
                doc = {key: value for key, value in (query or {}).items()
                       if not key.startswith("$") and not isinstance(value, dict)}
                doc["_id"] = str(doc.get("_id") or ObjectId())
                matched, upserted = 0, doc["_id"]
            else:
                matched, upserted = 1, None
            old = deepcopy(doc)
            if any(key.startswith("$") for key in update):
                for key, value in update.get("$set", {}).items():
                    _set_path(doc, key, value)
                for key, value in update.get("$inc", {}).items():
                    current = _get(doc, key) or 0
                    _set_path(doc, key, current + value)
                for key in update.get("$unset", {}):
                    _unset_path(doc, key)
            else:
                doc = deepcopy(update)
                doc.setdefault("_id", old["_id"])
            doc = self._normalize(doc)
            await self._check_unique(doc, excluding=old.get("_id") if matched else None)
            await self._save(doc, insert=(matched == 0))
            return UpdateResult(matched, 1, upserted)

    async def replace_one(self, query, replacement, upsert=False):
        async with self._write_lock:
            old = await self.find_one(query)
            if old is None and not upsert:
                return UpdateResult()
            doc = deepcopy(replacement)
            doc["_id"] = str((old or {}).get("_id", doc.get("_id") or ObjectId()))
            doc = self._normalize(doc)
            await self._check_unique(doc, excluding=(old or {}).get("_id"))
            await self._save(doc, insert=(old is None))
            return UpdateResult(1 if old else 0, 1, None if old else doc["_id"])

    async def delete_one(self, query):
        async with self._write_lock:
            for document in await self._all():
                if _matches(document, query):
                    await self._delete_id(document["_id"])
                    return DeleteResult(1)
        return DeleteResult()

    async def delete_many(self, query):
        async with self._write_lock:
            ids = [doc["_id"] for doc in await self._all() if _matches(doc, query)]
            for document_id in ids:
                await self._delete_id(document_id)
        return DeleteResult(len(ids))

    async def _delete_id(self, document_id):
        await self.db.initialize()
        async with self.db.pool.acquire() as connection:
            async with connection.cursor() as cursor:
                await cursor.execute(
                    "DELETE FROM survey_documents WHERE collection_name=%s AND document_id=%s",
                    (self.name, str(document_id)),
                )
            await connection.commit()

    async def find_one_and_update(self, query, update, return_document=None, upsert=False):
        # The high-contention reference counter uses Database.increment_counter.
        # Other legacy calls use update_one's write lock; do not re-enter that lock here.
        before = await self.find_one(query)
        if before is None and not upsert:
            return None
        await self.update_one(query, update, upsert=upsert)
        wants_after = return_document is True or return_document == 1
        return await self.find_one(query) if wants_after else before


class Database:
    def __init__(self):
        self.pool = None
        self._init_lock = asyncio.Lock()
        self._collections = {}
        self._schema_ready = False
        raw = os.getenv("MYSQL_URL", "mysql://root:password@127.0.0.1:3306/simple_survei")
        if raw.startswith(("mysql://", "mysql+aiomysql://")):
            parsed = urlparse(raw.replace("mysql+aiomysql://", "mysql://", 1))
            self.config = {
                "host": parsed.hostname or "127.0.0.1",
                "port": parsed.port or 3306,
                "user": unquote(parsed.username or "root"),
                "password": unquote(parsed.password or ""),
                "db": (parsed.path or "/simple_survei").lstrip("/") or "simple_survei",
            }
        else:
            raise ValueError("MYSQL_URL harus menggunakan format mysql://user:password@host:3306/database")

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        if name not in self._collections:
            self._collections[name] = Collection(self, name)
        return self._collections[name]

    async def initialize(self):
        if self.pool is not None and self._schema_ready:
            return
        async with self._init_lock:
            if self.pool is not None and self._schema_ready:
                return
            try:
                if self.pool is None:
                    self.pool = await aiomysql.create_pool(
                        **self.config, minsize=1, maxsize=10, autocommit=False, charset="utf8mb4"
                    )
                async with self.pool.acquire() as connection:
                    async with connection.cursor(aiomysql.DictCursor) as cursor:
                        await cursor.execute(
                            """CREATE TABLE IF NOT EXISTS survey_documents (
                                collection_name VARCHAR(80) NOT NULL,
                                document_id VARCHAR(64) NOT NULL,
                                doc JSON NOT NULL,
                                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                PRIMARY KEY (collection_name, document_id),
                                INDEX idx_collection (collection_name)
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"""
                        )
                        await cursor.execute("SHOW COLUMNS FROM survey_documents")
                        existing_columns = {row["Field"] for row in await cursor.fetchall()}
                        generated_names = {"email_unique", "nik_unique", "reference_unique"}
                        if not generated_names.issubset(existing_columns):
                            # One-time compatibility migration for the earlier JSON-only table.
                            await cursor.execute(
                                "SELECT collection_name, document_id, doc FROM survey_documents "
                                "WHERE collection_name IN ('users', 'respondents')"
                            )
                            legacy_rows = await cursor.fetchall()
                            for legacy in legacy_rows:
                                raw_doc = legacy["doc"]
                                value = raw_doc if isinstance(raw_doc, dict) else json.loads(raw_doc)
                                changed = False
                                if legacy["collection_name"] == "users" and value.get("email"):
                                    normalized_email = str(value["email"]).strip().lower()
                                    if value["email"] != normalized_email:
                                        value["email"] = normalized_email
                                        changed = True
                                if legacy["collection_name"] == "respondents" and value.get("nik"):
                                    normalized_nik = re.sub(r"\D", "", str(value["nik"]))
                                    if value["nik"] != normalized_nik:
                                        value["nik"] = normalized_nik
                                        changed = True
                                if changed:
                                    await cursor.execute(
                                        "UPDATE survey_documents SET doc=%s WHERE collection_name=%s AND document_id=%s",
                                        (json.dumps(_plain(value), ensure_ascii=False, separators=(",", ":")),
                                         legacy["collection_name"], legacy["document_id"]),
                                    )
                        generated_columns = {
                            "email_unique": "VARCHAR(320) GENERATED ALWAYS AS (CASE WHEN collection_name='users' THEN NULLIF(LOWER(JSON_UNQUOTE(JSON_EXTRACT(doc, '$.email'))), '') ELSE NULL END) STORED",
                            "nik_unique": "VARCHAR(64) GENERATED ALWAYS AS (CASE WHEN collection_name='respondents' THEN NULLIF(JSON_UNQUOTE(JSON_EXTRACT(doc, '$.nik')), '') ELSE NULL END) STORED",
                            "reference_unique": "VARCHAR(80) GENERATED ALWAYS AS (CASE WHEN collection_name='respondents' THEN NULLIF(JSON_UNQUOTE(JSON_EXTRACT(doc, '$.reference_code')), '') ELSE NULL END) STORED",
                        }
                        for column, definition in generated_columns.items():
                            if column not in existing_columns:
                                await cursor.execute(f"ALTER TABLE survey_documents ADD COLUMN {column} {definition}")
                        # Fail with a useful explanation rather than leaving the API partially usable
                        # if an older database already contains duplicate unique values.
                        for column, label in (("email_unique", "email admin"),
                                              ("nik_unique", "NIK responden"),
                                              ("reference_unique", "kode referensi")):
                            await cursor.execute(
                                f"SELECT {column} AS value, COUNT(*) AS qty FROM survey_documents "
                                f"WHERE {column} IS NOT NULL GROUP BY {column} HAVING COUNT(*) > 1 LIMIT 5"
                            )
                            duplicates = await cursor.fetchall()
                            if duplicates:
                                sample = ", ".join(str(row["value"]) for row in duplicates)
                                raise RuntimeError(
                                    f"Migrasi MySQL dibatalkan: ditemukan duplikasi {label} ({sample}). "
                                    "Bersihkan duplikasi tersebut lalu jalankan aplikasi kembali."
                                )
                        await cursor.execute("SHOW INDEX FROM survey_documents")
                        existing_indexes = {row["Key_name"] for row in await cursor.fetchall()}
                        unique_indexes = {
                            "uq_survey_users_email": "email_unique",
                            "uq_survey_respondents_nik": "nik_unique",
                            "uq_survey_respondents_reference": "reference_unique",
                        }
                        for index, column in unique_indexes.items():
                            if index not in existing_indexes:
                                await cursor.execute(f"ALTER TABLE survey_documents ADD UNIQUE INDEX {index} ({column})")
                    await connection.commit()
                self._schema_ready = True
            except Exception:
                # Do not leave a half-initialized pool that makes subsequent attempts falsely pass.
                if self.pool is not None:
                    self.pool.close()
                    await self.pool.wait_closed()
                    self.pool = None
                self._schema_ready = False
                raise

    async def increment_counter(self, name: str) -> int:
        """Atomically increment a counter and return this caller's exact sequence value."""
        await self.initialize()
        async with self.pool.acquire() as connection:
            async with connection.cursor(aiomysql.DictCursor) as cursor:
                await cursor.execute(
                    """INSERT INTO survey_documents (collection_name, document_id, doc)
                       VALUES ('counters', %s, JSON_OBJECT('_id', %s, 'seq', LAST_INSERT_ID(1)))
                       ON DUPLICATE KEY UPDATE doc=JSON_SET(
                           doc, '$.seq', LAST_INSERT_ID(
                               CAST(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(doc, '$.seq')), '0') AS UNSIGNED) + 1
                           )
                       )""",
                    (str(name), str(name)),
                )
                await cursor.execute("SELECT LAST_INSERT_ID() AS seq")
                row = await cursor.fetchone()
            await connection.commit()
        return int(row["seq"])

    async def close(self):
        if self.pool is not None:
            self.pool.close()
            await self.pool.wait_closed()
            self.pool = None
            self._schema_ready = False


db = Database()


class MySQLClient:
    async def close(self):
        await db.close()


client = MySQLClient()

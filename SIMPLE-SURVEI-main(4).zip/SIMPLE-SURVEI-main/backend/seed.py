"""Seed default survey configuration, settings and 9 SKM indicators."""
from core import db, now_utc
from scoring import DEFAULT_CATEGORIES

DEFAULT_PEKERJAAN = ["TNI", "Dosen", "Polri", "Dokter", "Guru", "Tenaga Kesehatan",
                     "ASN", "Karyawan Swasta", "Wiraswasta", "Pedagang", "Buruh", "Lainnya"]
DEFAULT_PENDIDIKAN = ["SD", "SMP", "SMA", "Diploma", "S1", "S2", "S3"]

RATING_LABELS_5 = {
    "1": "Tidak Baik", "2": "Kurang Baik", "3": "Cukup Baik",
    "4": "Baik", "5": "Sangat Baik",
}

SKM_UNSUR = [
    "Persyaratan Pelayanan",
    "Sistem, Mekanisme dan Prosedur",
    "Waktu Penyelesaian",
    "Biaya/Tarif",
    "Produk Spesifikasi Jenis Pelayanan",
    "Kompetensi Pelaksana",
    "Perilaku Pelaksana",
    "Penanganan Pengaduan, Saran dan Masukan",
    "Sarana dan Prasarana",
]

SKM_QUESTIONS = [
    "Bagaimana pendapat Anda tentang kesesuaian persyaratan pelayanan dengan jenis pelayanannya?",
    "Bagaimana pemahaman Anda tentang kemudahan prosedur pelayanan di unit ini?",
    "Bagaimana pendapat Anda tentang kecepatan waktu dalam memberikan pelayanan?",
    "Bagaimana pendapat Anda tentang kewajaran biaya/tarif dalam pelayanan?",
    "Bagaimana pendapat Anda tentang kesesuaian produk pelayanan dengan ketentuan?",
    "Bagaimana pendapat Anda tentang kompetensi/kemampuan petugas dalam pelayanan?",
    "Bagaimana pendapat Anda tentang perilaku petugas dalam pelayanan terkait kesopanan dan keramahan?",
    "Bagaimana pendapat Anda tentang penanganan pengaduan, saran dan masukan?",
    "Bagaimana pendapat Anda tentang kualitas sarana dan prasarana?",
]


async def seed_defaults():
    if await db.settings.find_one({"_id": "app"}) is None:
        await db.settings.insert_one({
            "_id": "app",
            "app_name": "AKU Online",
            "instansi": "Pemerintah Kabupaten Buleleng",
            "logo_url": "/assets/logo.jpg",
            "favicon_url": "/assets/logo.jpg",
            "address": "Jl. Ngurah Rai No.2, Singaraja, Buleleng, Bali",
            "email": "info@bulelengkab.go.id",
            "contact": "(0362) 22048",
            "website": "https://akuonline.bulelengkab.go.id/",
            "primary_color": "#C81E1E",
            "pdf_footer": "Dokumen ini dihasilkan secara otomatis oleh sistem AKU Online - Pemerintah Kabupaten Buleleng.",
            "timezone": "Asia/Makassar",
        })

    if await db.survey.find_one({"_id": "main"}) is None:
        await db.survey.insert_one({
            "_id": "main",
            "title": "Survei Kepuasan Masyarakat (SKM)",
            "description": "Survei untuk mengukur tingkat kepuasan masyarakat terhadap pelayanan publik di lingkungan Pemerintah Kabupaten Buleleng.",
            "service_name": "Pelayanan Publik Pemkab Buleleng",
            "period_start": None,
            "period_end": None,
            "status": "open",
            "intro_info": "Selamat datang. Partisipasi Anda sangat berarti untuk meningkatkan kualitas pelayanan publik.",
            "instructions": "Mohon isi data diri dan berikan penilaian sesuai pengalaman Anda. Seluruh data dijamin kerahasiaannya.",
            "closing_info": "Terima kasih telah berpartisipasi dalam survei ini.",
            "scale": {"type": "star_1_5", "min": 1, "max": 5, "labels": RATING_LABELS_5},
            "categories": DEFAULT_CATEGORIES,
            "respondent_fields": {
                "nama": {"required": True, "visible": True},
                "nik": {"required": True, "visible": True},
                "whatsapp": {"required": False, "visible": True},
                "email": {"required": False, "visible": True},
                "pekerjaan": {"required": True, "visible": True},
                "pendidikan": {"required": True, "visible": True},
            },
            "pekerjaan_options": DEFAULT_PEKERJAAN,
            "pendidikan_options": DEFAULT_PENDIDIKAN,
            "updated_at": now_utc().isoformat(),
        })

    if await db.questions.count_documents({}) == 0:
        docs = []
        for i, (unsur, text) in enumerate(zip(SKM_UNSUR, SKM_QUESTIONS)):
            docs.append({
                "text": text,
                "type": "rating_5",
                "order": i,
                "required": True,
                "indicator": unsur,
                "weight": 1,
                "options": [],
                "rating_max": 5,
                "rating_labels": RATING_LABELS_5,
                "created_at": now_utc().isoformat(),
            })
        if docs:
            await db.questions.insert_many(docs)

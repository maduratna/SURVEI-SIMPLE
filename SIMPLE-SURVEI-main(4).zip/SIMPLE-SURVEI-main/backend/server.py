from dotenv import load_dotenv
from pathlib import Path
import os
import logging

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from starlette.middleware.cors import CORSMiddleware
from pymongo.errors import DuplicateKeyError

from core import db, logger
from auth import router as auth_router, seed_admin
from survey_routes import router as survey_router
from admin_routes import router as admin_router
from reports import router as reports_router
from seed import seed_defaults

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")

app = FastAPI(title="AKU Online Survey Management System")

app.include_router(auth_router)
app.include_router(survey_router)
app.include_router(admin_router)
app.include_router(reports_router)


@app.get("/api/health")
async def health():
    # A process-level health check without a database check can give false positives.
    try:
        await db.initialize()
        async with db.pool.acquire() as connection:
            async with connection.cursor() as cursor:
                await cursor.execute("SELECT 1")
                await cursor.fetchone()
        return {"status": "ok", "database": "ok"}
    except Exception:
        logger.exception("Health check database failure")
        return JSONResponse(status_code=503, content={"status": "degraded", "database": "unavailable"})


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled error on {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(status_code=500,
                        content={"detail": "Terjadi kesalahan pada server. Silakan coba lagi."})


frontend_url = os.environ.get("FRONTEND_URL", "http://localhost:3000")
origins = [frontend_url]
extra = os.environ.get("CORS_ORIGINS", "")
if extra and extra != "*":
    origins += [o for o in extra.split(",") if o]

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=list(set(origins)) or ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    try:
        await db.users.create_index("email", unique=True)
        await db.respondents.create_index("nik", unique=True,
                                          partialFilterExpression={"nik": {"$gt": ""}})
        await db.respondents.create_index("created_at")
        await db.respondents.create_index("reference_code", unique=True)
        await db.questions.create_index("order")
        await db.password_reset_tokens.create_index("expires_at", expireAfterSeconds=0)
        await db.login_attempts.create_index("identifier")
        await db.audit_logs.create_index("created_at")
    except Exception as e:
        logger.warning(f"index creation: {e}")
    await seed_admin()
    await seed_defaults()
    logger.info("AKU Online started: indexes ready, defaults seeded.")


@app.on_event("shutdown")
async def shutdown():
    from core import client
    await client.close()

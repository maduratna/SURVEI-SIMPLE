"""Configurable scoring engine for IKM/SKM."""

SCORING_TYPES = {"rating_5", "rating_4", "custom_rating"}

DEFAULT_CATEGORIES = [
    {"grade": "A", "label": "Sangat Baik", "min": 88.31, "max": 100.0, "color": "#15803D"},
    {"grade": "B", "label": "Baik", "min": 76.61, "max": 88.30, "color": "#2563EB"},
    {"grade": "C", "label": "Kurang Baik", "min": 65.00, "max": 76.60, "color": "#D97706"},
    {"grade": "D", "label": "Tidak Baik", "min": 0.0, "max": 64.99, "color": "#DC2626"},
]


def question_max(q: dict) -> int:
    t = q.get("type")
    if t == "rating_5":
        return 5
    if t == "rating_4":
        return 4
    if t == "custom_rating":
        return int(q.get("rating_max") or 5)
    return 0


def category_from_score(score, categories):
    if score is None:
        return None
    for c in (categories or DEFAULT_CATEGORIES):
        if c["min"] <= score <= c["max"]:
            return {"grade": c.get("grade"), "label": c["label"], "color": c.get("color")}
    return {"grade": "-", "label": "Belum Dinilai", "color": "#64748B"}


def compute_respondent_score(answers: list, qmap: dict, categories=None):
    """answers: [{question_id, value}]  -> (score_0_100, {indicator: normalized_pct})"""
    total_w = 0.0
    total = 0.0
    indicator_vals = {}
    for a in answers:
        q = qmap.get(a.get("question_id"))
        if not q or q.get("type") not in SCORING_TYPES:
            continue
        qmax = question_max(q)
        if not qmax:
            continue
        try:
            val = float(a.get("value"))
        except (TypeError, ValueError):
            continue
        norm = max(0.0, min(1.0, val / qmax))
        w = float(q.get("weight") or 1)
        total += norm * w
        total_w += w
        ind = q.get("indicator") or "Umum"
        indicator_vals.setdefault(ind, []).append(norm)
    if total_w == 0:
        return None, {}
    score = round((total / total_w) * 100, 2)
    ind_pct = {k: round(sum(v) / len(v) * 100, 2) for k, v in indicator_vals.items()}
    return score, ind_pct

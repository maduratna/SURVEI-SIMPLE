"""Authentication: JWT cookie auth, login rate limiting, admin seeding."""
import os
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from fastapi import APIRouter, Request, Response, HTTPException, Depends
from pydantic import BaseModel, EmailStr

from core import db, get_current_user, now_utc, write_audit

router = APIRouter(prefix="/api/auth", tags=["auth"])

JWT_ALG = "HS256"
ACCESS_MINUTES = 60 * 8          # 8h working session
REFRESH_DAYS = 7
MAX_ATTEMPTS = 5
LOCKOUT_MINUTES = 15


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def _secret() -> str:
    return os.environ["JWT_SECRET"]


def create_access_token(uid: str, email: str) -> str:
    payload = {"sub": uid, "email": email, "type": "access",
               "exp": datetime.now(timezone.utc) + timedelta(minutes=ACCESS_MINUTES)}
    return jwt.encode(payload, _secret(), algorithm=JWT_ALG)


def create_refresh_token(uid: str) -> str:
    payload = {"sub": uid, "type": "refresh",
               "exp": datetime.now(timezone.utc) + timedelta(days=REFRESH_DAYS)}
    return jwt.encode(payload, _secret(), algorithm=JWT_ALG)


def _cookie_options():
    # Local HTTP development needs non-secure cookies; production should set COOKIE_SECURE=true.
    secure = os.getenv("COOKIE_SECURE", "false").lower() == "true"
    return {"httponly": True, "secure": secure, "samesite": "none" if secure else "lax", "path": "/"}


def _set_cookies(response: Response, access: str, refresh: str):
    options = _cookie_options()
    response.set_cookie("access_token", access, max_age=ACCESS_MINUTES * 60, **options)
    response.set_cookie("refresh_token", refresh, max_age=REFRESH_DAYS * 86400, **options)


class LoginBody(BaseModel):
    email: EmailStr
    password: str


@router.post("/login")
async def login(body: LoginBody, request: Request, response: Response):
    email = body.email.lower().strip()
    ip = request.client.host if request.client else "unknown"
    identifier = f"{ip}:{email}"

    attempt = await db.login_attempts.find_one({"identifier": identifier})
    if attempt and attempt.get("count", 0) >= MAX_ATTEMPTS:
        locked_until = attempt.get("locked_until")
        if locked_until and now_utc() < datetime.fromisoformat(locked_until):
            raise HTTPException(status_code=429,
                                detail="Terlalu banyak percobaan. Silakan coba lagi dalam beberapa menit.")

    user = await db.users.find_one({"email": email})
    if not user or not verify_password(body.password, user.get("password_hash", "")):
        locked_until = (now_utc() + timedelta(minutes=LOCKOUT_MINUTES)).isoformat()
        await db.login_attempts.update_one(
            {"identifier": identifier},
            {"$inc": {"count": 1}, "$set": {"locked_until": locked_until}},
            upsert=True,
        )
        raise HTTPException(status_code=401, detail="Email atau kata sandi salah.")

    await db.login_attempts.delete_one({"identifier": identifier})
    uid = str(user["_id"])
    _set_cookies(response, create_access_token(uid, email), create_refresh_token(uid))
    await write_audit({"email": email, "name": user.get("name")}, "login")
    return {"id": uid, "email": email, "name": user.get("name"), "role": user.get("role", "admin")}


@router.post("/refresh")
async def refresh(request: Request, response: Response):
    token = request.cookies.get("refresh_token")
    if not token:
        raise HTTPException(status_code=401, detail="Sesi tidak ditemukan.")
    try:
        payload = jwt.decode(token, _secret(), algorithms=[JWT_ALG])
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Token tidak valid.")
        from bson import ObjectId
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="Pengguna tidak ditemukan.")
        response.set_cookie("access_token", create_access_token(str(user["_id"]), user["email"]),
                            max_age=ACCESS_MINUTES * 60, **_cookie_options())
        return {"ok": True}
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Sesi telah berakhir.")


@router.post("/logout")
async def logout(response: Response, user: dict = Depends(get_current_user)):
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    await write_audit(user, "logout")
    return {"ok": True}


@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    return user


async def seed_admin():
    email = os.environ["ADMIN_EMAIL"].lower().strip()
    password = os.environ["ADMIN_PASSWORD"]
    existing = await db.users.find_one({"email": email})
    if existing is None:
        await db.users.insert_one({
            "email": email,
            "password_hash": hash_password(password),
            "name": "Super Admin",
            "role": "admin",
            "created_at": now_utc().isoformat(),
        })
    elif not verify_password(password, existing.get("password_hash", "")):
        await db.users.update_one({"email": email},
                                  {"$set": {"password_hash": hash_password(password)}})

"""Shared core: db connection, helpers, auth dependency, audit, timezone."""
import os
import logging
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from fastapi import Request, HTTPException
from bson import ObjectId
from mysql_store import db, client

logger = logging.getLogger("akuonline")


WITA = ZoneInfo("Asia/Makassar")

MONTHS_ID = [
    "", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
]


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def to_wita(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(WITA)


def format_wita(dt: datetime) -> str:
    w = to_wita(dt)
    return f"{w.day:02d} {MONTHS_ID[w.month]} {w.year}, {w.strftime('%H:%M:%S')} WITA"


def serialize(doc: dict) -> dict:
    """Convert a database document into a JSON-safe dict (id->str as 'id')."""
    if not doc:
        return doc
    out = dict(doc)
    if "_id" in out:
        out["id"] = str(out.pop("_id"))
    return out


async def next_sequence(name: str) -> int:
    # Use a single MySQL atomic increment so concurrent survey submissions never
    # receive the same reference sequence, including on the first submission.
    return await db.increment_counter(name)


async def get_current_user(request: Request) -> dict:
    import jwt
    token = request.cookies.get("access_token")
    if not token:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Sesi tidak ditemukan. Silakan masuk kembali.")
    try:
        payload = jwt.decode(token, os.environ["JWT_SECRET"], algorithms=["HS256"])
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Token tidak valid.")
        user = await db.users.find_one({"_id": ObjectId(payload["sub"])})
        if not user:
            raise HTTPException(status_code=401, detail="Pengguna tidak ditemukan.")
        user.pop("password_hash", None)
        return serialize(user)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Sesi telah berakhir. Silakan masuk kembali.")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token tidak valid.")


async def write_audit(user: dict, action: str, metadata: dict | None = None):
    try:
        await db.audit_logs.insert_one({
            "admin_email": (user or {}).get("email", "system"),
            "admin_name": (user or {}).get("name", "System"),
            "action": action,
            "metadata": metadata or {},
            "created_at": now_utc().isoformat(),
        })
    except Exception as e:  # never let audit break a flow
        logger.warning(f"audit failed: {e}")

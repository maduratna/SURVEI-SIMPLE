"""Admin: dashboard, analytics, respondents, reset, settings, backup/restore, audit."""
import re
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional
from bson import ObjectId
import json

from core import (db, get_current_user, now_utc, serialize, to_wita, WITA,
                  format_wita, write_audit, MONTHS_ID)
from scoring import category_from_score

router = APIRouter(prefix="/api", tags=["admin"])


# ---------- masking ----------
def mask_nik(nik):
    if not nik or len(nik) < 4:
        return nik or ""
    return "*" * 12 + nik[-4:]


def mask_wa(wa):
    if not wa:
        return ""
    return (wa[:6] + "****" + wa[-3:]) if len(wa) > 9 else wa


def mask_email(e):
    if not e or "@" not in e:
        return e or ""
    name, dom = e.split("@", 1)
    return (name[:2] if len(name) >= 2 else name) + "***@" + dom


def mask_nama(n):
    if not n:
        return ""
    parts = n.split(" ")
    if len(parts) == 1:
        return parts[0][:3] + "***"
    return parts[0] + " " + " ".join(p[0] + "***" for p in parts[1:])


# ---------- period ----------
def period_range(period, start, end):
    now = to_wita(now_utc())
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)

    def wita_to_utc_iso(dt):
        return dt.astimezone(timezone.utc).isoformat()

    label = ""
    if period == "today":
        s, e, label = today, today + timedelta(days=1), "Hari Ini"
    elif period == "yesterday":
        s, e, label = today - timedelta(days=1), today, "Kemarin"
    elif period == "this_week":
        s = today - timedelta(days=today.weekday())
        e, label = s + timedelta(days=7), "Minggu Ini"
    elif period == "this_month":
        s = today.replace(day=1)
        nm = (s + timedelta(days=32)).replace(day=1)
        e, label = nm, "Bulan Ini"
    elif period == "quarter":
        q = (now.month - 1) // 3
        s = today.replace(month=q * 3 + 1, day=1)
        e = (s + timedelta(days=100)).replace(day=1)
        label = "Triwulan Ini"
    elif period == "semester":
        sm = 1 if now.month <= 6 else 7
        s = today.replace(month=sm, day=1)
        e = today.replace(month=(sm + 6) if sm == 1 else 12, day=1)
        if sm == 7:
            e = today.replace(year=now.year + 1, month=1, day=1)
        else:
            e = today.replace(month=7, day=1)
        label = "Semester Ini"
    elif period == "year":
        s = today.replace(month=1, day=1)
        e, label = today.replace(year=now.year + 1, month=1, day=1), "Tahun Ini"
    elif period == "custom" and start and end:
        s = datetime.fromisoformat(start).replace(tzinfo=WITA, hour=0, minute=0, second=0, microsecond=0)
        e = datetime.fromisoformat(end).replace(tzinfo=WITA, hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
        label = f"{start} s/d {end}"
    else:  # all
        return None, None, "Semua Periode"
    return wita_to_utc_iso(s), wita_to_utc_iso(e), label


def range_query(start_iso, end_iso):
    q = {}
    if start_iso and end_iso:
        q["created_at"] = {"$gte": start_iso, "$lt": end_iso}
    return q


# ---------- shared stats ----------
async def gather_stats(start_iso, end_iso):
    survey = await db.survey.find_one({"_id": "main"})
    categories = survey.get("categories") if survey else None
    q = range_query(start_iso, end_iso)
    docs = await db.respondents.find(q, {"nik": 0, "whatsapp": 0, "email": 0, "nama": 0}).to_list(100000)

    total = len(docs)
    scores = [d["score"] for d in docs if d.get("score") is not None]
    ikm = round(sum(scores) / len(scores), 2) if scores else None
    category = category_from_score(ikm, categories) if ikm is not None else None
    suggestions = [d for d in docs if (d.get("suggestion") or "").strip()]

    pekerjaan, pendidikan, rating_dist = {}, {}, {}
    indicator_acc = {}
    trend = {}
    trend_scores = {}
    for d in docs:
        pekerjaan[d.get("pekerjaan") or "Lainnya"] = pekerjaan.get(d.get("pekerjaan") or "Lainnya", 0) + 1
        pendidikan[d.get("pendidikan") or "-"] = pendidikan.get(d.get("pendidikan") or "-", 0) + 1
        for a in d.get("answers", []):
            if a.get("type") in ("rating_5", "rating_4", "custom_rating"):
                v = str(a.get("value"))
                rating_dist[v] = rating_dist.get(v, 0) + 1
        for ind, pct in (d.get("indicator_scores") or {}).items():
            indicator_acc.setdefault(ind, []).append(pct)
        wk = to_wita(datetime.fromisoformat(d["created_at"]))
        key = wk.strftime("%Y-%m-%d")
        trend[key] = trend.get(key, 0) + 1
        if d.get("score") is not None:
            trend_scores.setdefault(key, []).append(d["score"])

    indicators = [{"indicator": k, "score": round(sum(v) / len(v), 2), "count": len(v)}
                  for k, v in indicator_acc.items()]
    indicators.sort(key=lambda x: x["indicator"])

    highest = max(indicators, key=lambda x: x["score"]) if indicators else None
    lowest = min(indicators, key=lambda x: x["score"]) if indicators else None

    # count today / this month absolute
    now = to_wita(now_utc())
    tstart = now.replace(hour=0, minute=0, second=0, microsecond=0)
    today_count = await db.respondents.count_documents(
        {"created_at": {"$gte": tstart.astimezone(timezone.utc).isoformat()}})
    mstart = tstart.replace(day=1)
    month_count = await db.respondents.count_documents(
        {"created_at": {"$gte": mstart.astimezone(timezone.utc).isoformat()}})
    grand_total = await db.respondents.count_documents({})

    return {
        "total": total, "grand_total": grand_total,
        "today_count": today_count, "month_count": month_count,
        "ikm": ikm, "category": category,
        "suggestions_count": len(suggestions),
        "pekerjaan": [{"name": k, "value": v} for k, v in sorted(pekerjaan.items(), key=lambda x: -x[1])],
        "pendidikan": [{"name": k, "value": v} for k, v in sorted(pendidikan.items(), key=lambda x: -x[1])],
        "rating_distribution": [{"name": k, "value": rating_dist[k]} for k in sorted(rating_dist.keys())],
        "indicators": indicators,
        "highest": highest, "lowest": lowest,
        "trend": [{"date": k, "value": trend[k]} for k in sorted(trend.keys())],
        "ikm_trend": [{"date": k, "value": round(sum(v) / len(v), 2)} for k, v in sorted(trend_scores.items())],
        "suggestions": [{"text": s.get("suggestion"), "reference_code": s.get("reference_code"),
                         "created_at": s.get("created_at")} for s in suggestions],
    }


@router.get("/dashboard")
async def dashboard(period: str = "all", start: Optional[str] = None,
                    end: Optional[str] = None, user: dict = Depends(get_current_user)):
    survey = await db.survey.find_one({"_id": "main"})
    start_iso, end_iso, label = period_range(period, start, end)
    stats = await gather_stats(start_iso, end_iso)

    recent_docs = await db.respondents.find(range_query(start_iso, end_iso)).sort("created_at", -1).limit(5).to_list(5)
    recent = [{
        "reference_code": r.get("reference_code"),
        "nama": mask_nama(r.get("nama")),
        "created_at_formatted": format_wita(datetime.fromisoformat(r["created_at"])),
        "score": r.get("score"),
        "category": r.get("category"),
    } for r in recent_docs]

    # summary text
    summary = []
    summary.append(f"Pada periode ini terdapat {stats['total']} responden.")
    if stats["ikm"] is not None:
        cat = stats["category"]["label"] if stats["category"] else "-"
        summary.append(f"Nilai IKM sebesar {stats['ikm']} dengan kategori {cat}.")
    if stats["highest"]:
        summary.append(f"Unsur tertinggi: {stats['highest']['indicator']} ({stats['highest']['score']}).")
    if stats["lowest"]:
        summary.append(f"Unsur yang perlu diperhatikan: {stats['lowest']['indicator']} ({stats['lowest']['score']}).")

    return {
        "survey_status": survey.get("status") if survey else "closed",
        "survey_title": survey.get("title") if survey else "",
        "period_label": label,
        "kpi": {
            "total": stats["total"], "grand_total": stats["grand_total"],
            "today": stats["today_count"], "month": stats["month_count"],
            "ikm": stats["ikm"], "category": stats["category"],
            "suggestions": stats["suggestions_count"],
        },
        "charts": {
            "trend": stats["trend"], "pekerjaan": stats["pekerjaan"],
            "pendidikan": stats["pendidikan"], "rating_distribution": stats["rating_distribution"],
            "indicators": stats["indicators"], "ikm_trend": stats["ikm_trend"],
        },
        "summary": summary,
        "recent": recent,
    }


@router.get("/analytics")
async def analytics(period: str = "all", start: Optional[str] = None,
                    end: Optional[str] = None, user: dict = Depends(get_current_user)):
    start_iso, end_iso, label = period_range(period, start, end)
    stats = await gather_stats(start_iso, end_iso)
    return {
        "period_label": label,
        "total": stats["total"],
        "ikm": stats["ikm"],
        "category": stats["category"],
        "indicators": stats["indicators"],
        "highest": stats["highest"],
        "lowest": stats["lowest"],
        "rating_distribution": stats["rating_distribution"],
        "trend": stats["trend"],
    }


# ---------- respondents ----------
@router.get("/respondents")
async def list_respondents(
    search: Optional[str] = None, pekerjaan: Optional[str] = None,
    pendidikan: Optional[str] = None, category: Optional[str] = None,
    start: Optional[str] = None, end: Optional[str] = None,
    page: int = 1, page_size: int = 10, user: dict = Depends(get_current_user)):
    query = {}
    if search:
        s = re.escape(search)
        query["$or"] = [
            {"nama": {"$regex": s, "$options": "i"}},
            {"nik": {"$regex": s}},
            {"whatsapp": {"$regex": s}},
            {"email": {"$regex": s, "$options": "i"}},
            {"reference_code": {"$regex": s, "$options": "i"}},
            {"registration_number": {"$regex": s, "$options": "i"}},
        ]
    if pekerjaan:
        query["pekerjaan"] = pekerjaan
    if pendidikan:
        query["pendidikan"] = pendidikan
    if category:
        query["category.grade"] = category
    if start and end:
        s_iso = datetime.fromisoformat(start).replace(tzinfo=WITA).astimezone(timezone.utc).isoformat()
        e_iso = (datetime.fromisoformat(end).replace(tzinfo=WITA) + timedelta(days=1)).astimezone(timezone.utc).isoformat()
        query["created_at"] = {"$gte": s_iso, "$lt": e_iso}

    total = await db.respondents.count_documents(query)
    page = max(1, page)
    skip = (page - 1) * page_size
    docs = await db.respondents.find(query).sort("created_at", -1).skip(skip).limit(page_size).to_list(page_size)
    items = []
    for d in docs:
        items.append({
            "id": str(d["_id"]),
            "reference_code": d.get("reference_code"),
            "registration_number": d.get("registration_number"),
            "nama": d.get("nama"),
            "nik": mask_nik(d.get("nik")),
            "whatsapp": mask_wa(d.get("whatsapp")),
            "email": mask_email(d.get("email")),
            "pekerjaan": d.get("pekerjaan"),
            "pendidikan": d.get("pendidikan"),
            "score": d.get("score"),
            "category": d.get("category"),
            "created_at_formatted": format_wita(datetime.fromisoformat(d["created_at"])),
        })
    return {"items": items, "total": total, "page": page, "page_size": page_size,
            "pages": (total + page_size - 1) // page_size}


@router.get("/respondents/{rid}")
async def get_respondent(rid: str, user: dict = Depends(get_current_user)):
    d = await db.respondents.find_one({"_id": ObjectId(rid)})
    if not d:
        raise HTTPException(status_code=404, detail="Responden tidak ditemukan.")
    questions = await db.questions.find().sort("order", 1).to_list(500)
    qmap = {str(q["_id"]): q for q in questions}
    answers = []
    for a in d.get("answers", []):
        q = qmap.get(a.get("question_id"))
        answers.append({
            "question": q.get("text") if q else a.get("question_id"),
            "indicator": a.get("indicator"),
            "value": a.get("value"),
        })
    out = serialize(d)
    out["created_at_formatted"] = format_wita(datetime.fromisoformat(d["created_at"]))
    out["answers_detail"] = answers
    return out


class RespondentUpdate(BaseModel):
    nama: Optional[str] = None
    whatsapp: Optional[str] = None
    email: Optional[str] = None
    pekerjaan: Optional[str] = None
    pendidikan: Optional[str] = None


@router.put("/respondents/{rid}")
async def update_respondent(rid: str, body: RespondentUpdate, user: dict = Depends(get_current_user)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if "nama" in updates:
        updates["nama"] = re.sub(r"\s+", " ", updates["nama"].strip()).upper()
    if "email" in updates:
        updates["email"] = updates["email"].strip().lower()
    updates["updated_at"] = now_utc().isoformat()
    res = await db.respondents.update_one({"_id": ObjectId(rid)}, {"$set": updates})
    if res.matched_count == 0:
        raise HTTPException(status_code=404, detail="Responden tidak ditemukan.")
    await write_audit(user, "edit_respondent", {"id": rid})
    return {"ok": True}


@router.delete("/respondents/{rid}")
async def delete_respondent(rid: str, user: dict = Depends(get_current_user)):
    res = await db.respondents.delete_one({"_id": ObjectId(rid)})
    if res.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Responden tidak ditemukan.")
    await write_audit(user, "delete_respondent", {"id": rid})
    return {"ok": True}


# ---------- reset ----------
@router.post("/reset")
async def reset_data(payload: dict, user: dict = Depends(get_current_user)):
    if not payload.get("confirm"):
        raise HTTPException(status_code=422, detail="Konfirmasi diperlukan.")
    await db.respondents.delete_many({})
    await db.counters.delete_one({"_id": "reference"})
    await write_audit(user, "reset_data")
    return {"ok": True}


# ---------- settings ----------
@router.get("/settings")
async def get_settings(user: dict = Depends(get_current_user)):
    d = await db.settings.find_one({"_id": "app"})
    if not d:
        raise HTTPException(status_code=404, detail="Pengaturan tidak ditemukan.")
    d["id"] = d.pop("_id")
    return d


class SettingsUpdate(BaseModel):
    app_name: Optional[str] = None
    instansi: Optional[str] = None
    logo_url: Optional[str] = None
    favicon_url: Optional[str] = None
    address: Optional[str] = None
    email: Optional[str] = None
    contact: Optional[str] = None
    website: Optional[str] = None
    primary_color: Optional[str] = None
    pdf_footer: Optional[str] = None
    timezone: Optional[str] = None


@router.put("/settings")
async def update_settings(body: SettingsUpdate, user: dict = Depends(get_current_user)):
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    await db.settings.update_one({"_id": "app"}, {"$set": updates})
    await write_audit(user, "settings_change", {"fields": list(updates.keys())})
    d = await db.settings.find_one({"_id": "app"})
    d["id"] = d.pop("_id")
    return d


# ---------- public settings (for favicon/logo/theme) ----------
@router.get("/public/settings")
async def public_settings():
    d = await db.settings.find_one({"_id": "app"})
    if not d:
        return {}
    return {
        "app_name": d.get("app_name"), "instansi": d.get("instansi"),
        "logo_url": d.get("logo_url"), "favicon_url": d.get("favicon_url"),
        "website": d.get("website"), "primary_color": d.get("primary_color"),
    }


# ---------- backup / restore ----------
@router.get("/backup")
async def backup(user: dict = Depends(get_current_user)):
    survey = await db.survey.find_one({"_id": "main"})
    settings = await db.settings.find_one({"_id": "app"})
    questions = await db.questions.find().sort("order", 1).to_list(500)
    respondents = await db.respondents.find().to_list(100000)
    audit = await db.audit_logs.find().sort("created_at", -1).limit(1000).to_list(1000)

    data = {
        "version": 1,
        "exported_at": now_utc().isoformat(),
        "survey": survey,
        "settings": settings,
        "questions": [serialize(q) for q in questions],
        "respondents": [serialize(r) for r in respondents],
        "audit_logs": [serialize(a) for a in audit],
    }
    await write_audit(user, "backup")
    fname = f"aku-online-backup-{to_wita(now_utc()).strftime('%Y%m%d-%H%M%S')}.json"
    return JSONResponse(content=json.loads(json.dumps(data, default=str)),
                        headers={"Content-Disposition": f'attachment; filename="{fname}"'})


@router.post("/restore/preview")
async def restore_preview(file: UploadFile = File(...), user: dict = Depends(get_current_user)):
    try:
        content = await file.read()
        data = json.loads(content)
    except Exception:
        raise HTTPException(status_code=422, detail="File backup tidak valid.")
    if "survey" not in data or "questions" not in data:
        raise HTTPException(status_code=422, detail="Struktur file backup tidak sesuai.")
    return {
        "valid": True,
        "exported_at": data.get("exported_at"),
        "questions": len(data.get("questions", [])),
        "respondents": len(data.get("respondents", [])),
        "has_settings": bool(data.get("settings")),
    }


@router.post("/restore")
async def restore(file: UploadFile = File(...), user: dict = Depends(get_current_user)):
    try:
        data = json.loads(await file.read())
    except Exception:
        raise HTTPException(status_code=422, detail="File backup tidak valid.")
    if "survey" not in data or "questions" not in data:
        raise HTTPException(status_code=422, detail="Struktur file backup tidak sesuai.")

    if data.get("survey"):
        sv = data["survey"]
        sv["_id"] = "main"
        sv.pop("id", None)
        await db.survey.replace_one({"_id": "main"}, sv, upsert=True)
    if data.get("settings"):
        st = data["settings"]
        st["_id"] = "app"
        st.pop("id", None)
        await db.settings.replace_one({"_id": "app"}, st, upsert=True)

    await db.questions.delete_many({})
    qs = []
    for q in data.get("questions", []):
        q.pop("id", None)
        q.pop("_id", None)
        qs.append(q)
    if qs:
        await db.questions.insert_many(qs)

    await db.respondents.delete_many({})
    rs = []
    for r in data.get("respondents", []):
        r.pop("id", None)
        r.pop("_id", None)
        rs.append(r)
    if rs:
        await db.respondents.insert_many(rs)

    await write_audit(user, "restore", {"questions": len(qs), "respondents": len(rs)})
    return {"ok": True, "questions": len(qs), "respondents": len(rs)}


# ---------- audit ----------
@router.get("/audit")
async def audit_logs(page: int = 1, page_size: int = 20, user: dict = Depends(get_current_user)):
    total = await db.audit_logs.count_documents({})
    skip = (max(1, page) - 1) * page_size
    docs = await db.audit_logs.find().sort("created_at", -1).skip(skip).limit(page_size).to_list(page_size)
    items = [{
        "id": str(d["_id"]),
        "admin_email": d.get("admin_email"),
        "action": d.get("action"),
        "metadata": d.get("metadata"),
        "created_at_formatted": format_wita(datetime.fromisoformat(d["created_at"])) if d.get("created_at") else "",
    } for d in docs]
    return {"items": items, "total": total, "page": page,
            "pages": (total + page_size - 1) // page_size}
